import io
import json
import unittest
from datetime import date
from unittest.mock import patch

from bot import (
    Task,
    build_message,
    call_vk_messages_send,
    deterministic_random_id,
    select_tasks,
    split_message,
    VkApiError,
)


def task(task_id, due, status="Запланировано", priority="Высокий"):
    return Task(
        id=task_id,
        block="Тест",
        task=f"Задача {task_id}",
        due_date=date.fromisoformat(due),
        owner="Брунов Иван",
        status=status,
        priority=priority,
        next_action="Сделать следующий шаг",
    )


class ReminderTests(unittest.TestCase):
    def test_selects_overdue_today_and_next_seven_days(self):
        today = date(2026, 8, 17)
        tasks = [
            task(1, "2026-08-16"),
            task(2, "2026-08-17"),
            task(3, "2026-08-24"),
            task(4, "2026-08-25"),
            task(5, "2026-08-16", status="Завершено"),
        ]
        selected = select_tasks(tasks, today, 7, ["Завершено", "Выполнено"])
        self.assertEqual([item.id for item in selected.overdue], [1])
        self.assertEqual([item.id for item in selected.due_today], [2])
        self.assertEqual([item.id for item in selected.upcoming], [3])

    def test_monday_message_uses_correct_name(self):
        today = date(2026, 8, 17)
        selected = select_tasks([task(1, "2026-08-18")], today, 7, ["Завершено"])
        message = build_message("Фронтовая агитбригада", selected, today, 7)
        self.assertIn("План недели", message)
        self.assertIn("Брунов Иван", message)
        self.assertNotIn("Бурунов", message)

    def test_message_splitting_preserves_text(self):
        text = "\n\n".join(["Блок " + ("а" * 80) for _ in range(8)])
        chunks = split_message(text, max_length=200)
        self.assertGreater(len(chunks), 1)
        self.assertTrue(all(len(chunk) <= 200 for chunk in chunks))
        self.assertEqual("\n\n".join(chunks), text)

    def test_random_id_is_stable(self):
        day = date(2026, 8, 17)
        self.assertEqual(
            deterministic_random_id(day, 0, "текст"),
            deterministic_random_id(day, 0, "текст"),
        )

    @patch("urllib.request.urlopen")
    def test_vk_api_success(self, urlopen):
        response = unittest.mock.MagicMock()
        response.read.return_value = json.dumps({"response": 123}).encode("utf-8")
        urlopen.return_value.__enter__.return_value = response
        message_id = call_vk_messages_send(
            token="secret",
            peer_id="123",
            message="Тест",
            random_id=1,
            api_version="5.199",
            api_url="https://api.vk.ru/method/messages.send",
        )
        self.assertEqual(message_id, 123)

    @patch("urllib.request.urlopen")
    def test_vk_api_error_does_not_expose_token(self, urlopen):
        response = unittest.mock.MagicMock()
        response.read.return_value = json.dumps(
            {"error": {"error_code": 901, "error_msg": "Can't send messages"}}
        ).encode("utf-8")
        urlopen.return_value.__enter__.return_value = response
        with self.assertRaises(VkApiError) as context:
            call_vk_messages_send(
                token="very-secret-token",
                peer_id="123",
                message="Тест",
                random_id=1,
                api_version="5.199",
                api_url="https://api.vk.ru/method/messages.send",
            )
        self.assertNotIn("very-secret-token", str(context.exception))


if __name__ == "__main__":
    unittest.main()
