#!/usr/bin/env python3
"""Daily VK reminders for the project «Фронтовая агитбригада»."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable, Sequence
from zoneinfo import ZoneInfo


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DATA_FILE = BASE_DIR / "data" / "tasks.json"
DEFAULT_SETTINGS_FILE = BASE_DIR / "config" / "settings.json"


class BotConfigurationError(RuntimeError):
    """Raised when a required setting or secret is missing."""


class VkApiError(RuntimeError):
    """Raised when VK rejects a request."""


@dataclass(frozen=True)
class Task:
    id: int
    block: str
    task: str
    due_date: date
    owner: str
    status: str
    priority: str
    next_action: str

    @classmethod
    def from_dict(cls, item: dict) -> "Task":
        return cls(
            id=int(item["id"]),
            block=str(item.get("block") or ""),
            task=str(item["task"]),
            due_date=date.fromisoformat(str(item["due_date"])),
            owner=str(item.get("owner") or "Не назначен"),
            status=str(item.get("status") or "Запланировано"),
            priority=str(item.get("priority") or "Обычный"),
            next_action=str(item.get("next_action") or "Уточнить следующее действие"),
        )


@dataclass(frozen=True)
class TaskSelection:
    overdue: tuple[Task, ...]
    due_today: tuple[Task, ...]
    upcoming: tuple[Task, ...]

    @property
    def total(self) -> int:
        return len(self.overdue) + len(self.due_today) + len(self.upcoming)


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_tasks(path: Path = DEFAULT_DATA_FILE) -> tuple[str, list[Task]]:
    payload = load_json(path)
    project = str(payload.get("project") or "Проект")
    tasks = [Task.from_dict(item) for item in payload.get("tasks", [])]
    if not tasks:
        raise BotConfigurationError(f"В {path} не найдено ни одной задачи")
    return project, tasks


def load_settings(path: Path = DEFAULT_SETTINGS_FILE) -> dict:
    return load_json(path)


def normalize_status(value: str) -> str:
    return " ".join(value.casefold().split())


def priority_rank(value: str) -> int:
    ranks = {"критический": 0, "высокий": 1, "обычный": 2, "низкий": 3}
    return ranks.get(normalize_status(value), 4)


def select_tasks(
    tasks: Iterable[Task],
    today: date,
    lookahead_days: int,
    completed_statuses: Sequence[str],
) -> TaskSelection:
    completed = {normalize_status(status) for status in completed_statuses}
    horizon = today + timedelta(days=lookahead_days)
    active = [task for task in tasks if normalize_status(task.status) not in completed]
    order = lambda task: (task.due_date, priority_rank(task.priority), task.id)

    overdue = tuple(sorted((task for task in active if task.due_date < today), key=order))
    due_today = tuple(sorted((task for task in active if task.due_date == today), key=order))
    upcoming = tuple(
        sorted((task for task in active if today < task.due_date <= horizon), key=order)
    )
    return TaskSelection(overdue=overdue, due_today=due_today, upcoming=upcoming)


MONTHS_RU = (
    "января",
    "февраля",
    "марта",
    "апреля",
    "мая",
    "июня",
    "июля",
    "августа",
    "сентября",
    "октября",
    "ноября",
    "декабря",
)


def format_date_ru(value: date, include_year: bool = False) -> str:
    result = f"{value.day} {MONTHS_RU[value.month - 1]}"
    if include_year:
        result += f" {value.year}"
    return result


def format_task(task: Task, overdue: bool = False) -> str:
    date_label = format_date_ru(task.due_date)
    if overdue:
        date_label += " — просрочено"
    return (
        f"• {date_label}: {task.task}\n"
        f"  Ответственный: {task.owner}\n"
        f"  Следующее действие: {task.next_action}"
    )


def format_section(title: str, tasks: Sequence[Task], overdue: bool = False) -> str:
    if not tasks:
        return ""
    items = "\n\n".join(format_task(task, overdue=overdue) for task in tasks)
    return f"{title} ({len(tasks)})\n{items}"


def build_message(
    project: str,
    selection: TaskSelection,
    today: date,
    lookahead_days: int,
) -> str:
    horizon = today + timedelta(days=lookahead_days)
    if today.weekday() == 0:
        heading = (
            f"{project}\nПлан недели: {format_date_ru(today)} — "
            f"{format_date_ru(horizon, include_year=True)}"
        )
    else:
        heading = f"{project}\nПлан на {format_date_ru(today, include_year=True)}"

    sections = [
        format_section("🔴 Просроченные задачи", selection.overdue, overdue=True),
        format_section("🟠 Срок сегодня", selection.due_today),
        format_section(f"🟡 Сроки в ближайшие {lookahead_days} дней", selection.upcoming),
    ]
    sections = [section for section in sections if section]

    if not sections:
        body = f"Активных сроков на ближайшие {lookahead_days} дней нет. Просроченных задач нет."
    else:
        body = "\n\n".join(sections)

    footer = (
        "\n\nПосле выполнения задачи обновите её статус в data/tasks.json — "
        "после этого бот перестанет о ней напоминать."
    )
    return f"{heading}\n\n{body}{footer}"


def split_message(message: str, max_length: int = 3500) -> list[str]:
    if len(message) <= max_length:
        return [message]

    blocks = message.split("\n\n")
    chunks: list[str] = []
    current = ""
    for block in blocks:
        candidate = block if not current else f"{current}\n\n{block}"
        if len(candidate) <= max_length:
            current = candidate
            continue
        if current:
            chunks.append(current)
        if len(block) <= max_length:
            current = block
        else:
            for start in range(0, len(block), max_length):
                chunks.append(block[start : start + max_length])
            current = ""
    if current:
        chunks.append(current)
    return chunks


def deterministic_random_id(day: date, chunk_index: int, message: str) -> int:
    seed = f"{day.isoformat()}:{chunk_index}:{message}".encode("utf-8")
    return int.from_bytes(hashlib.sha256(seed).digest()[:4], "big") & 0x7FFFFFFF


def call_vk_messages_send(
    *,
    token: str,
    peer_id: str,
    message: str,
    random_id: int,
    api_version: str,
    api_url: str,
    timeout: int = 20,
) -> int:
    data = urllib.parse.urlencode(
        {
            "peer_id": peer_id,
            "message": message,
            "random_id": random_id,
            "access_token": token,
            "v": api_version,
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        api_url,
        data=data,
        headers={"User-Agent": "frontovaya-agitbrigada-reminder/1.0"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as error:
        raise VkApiError(f"Не удалось связаться с VK API: {type(error).__name__}") from error

    if "error" in payload:
        error = payload["error"]
        code = error.get("error_code", "unknown")
        message_text = error.get("error_msg", "неизвестная ошибка")
        raise VkApiError(f"VK API вернул ошибку {code}: {message_text}")

    try:
        return int(payload["response"])
    except (KeyError, TypeError, ValueError) as error:
        raise VkApiError("VK API вернул неожиданный ответ") from error


def send_message(chunks: Sequence[str], day: date) -> None:
    token = os.getenv("VK_ACCESS_TOKEN", "").strip()
    peer_id = os.getenv("VK_PEER_ID", "").strip()
    if not token or not peer_id:
        raise BotConfigurationError(
            "Для отправки нужны секреты VK_ACCESS_TOKEN и VK_PEER_ID"
        )

    api_version = os.getenv("VK_API_VERSION", "5.199").strip()
    api_url = os.getenv(
        "VK_API_URL", "https://api.vk.ru/method/messages.send"
    ).strip()

    for index, chunk in enumerate(chunks):
        random_id = deterministic_random_id(day, index, chunk)
        attempts = 3
        for attempt in range(1, attempts + 1):
            try:
                message_id = call_vk_messages_send(
                    token=token,
                    peer_id=peer_id,
                    message=chunk,
                    random_id=random_id,
                    api_version=api_version,
                    api_url=api_url,
                )
                print(f"Сообщение {index + 1}/{len(chunks)} отправлено, id={message_id}")
                break
            except VkApiError:
                if attempt == attempts:
                    raise
                time.sleep(2 ** (attempt - 1))


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="Напечатать сообщение без отправки")
    parser.add_argument("--date", help="Дата проверки в формате YYYY-MM-DD")
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA_FILE, help="Путь к tasks.json")
    parser.add_argument(
        "--settings", type=Path, default=DEFAULT_SETTINGS_FILE, help="Путь к settings.json"
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        settings = load_settings(args.settings)
        timezone = ZoneInfo(str(settings.get("timezone", "Europe/Moscow")))
        today = date.fromisoformat(args.date) if args.date else datetime.now(timezone).date()
        lookahead_days = int(settings.get("lookahead_days", 7))
        completed_statuses = settings.get("completed_statuses", ["Завершено"])
        project, tasks = load_tasks(args.data)
        selection = select_tasks(tasks, today, lookahead_days, completed_statuses)
        message = build_message(project, selection, today, lookahead_days)
        chunks = split_message(message)

        if args.dry_run:
            print("\n\n--- ЧАСТЬ ---\n\n".join(chunks))
            return 0

        send_message(chunks, today)
        return 0
    except (BotConfigurationError, VkApiError, ValueError, OSError) as error:
        print(f"Ошибка: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
