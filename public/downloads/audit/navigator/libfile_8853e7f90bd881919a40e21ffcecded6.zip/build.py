import re,json,pathlib,csv,fitz,copy,collections,zipfile,html
base=pathlib.Path('/mnt/data'); prev=base/'Навигатор_Первых_проверка_сроков_2026';out=base/'Навигатор_Первых_сверка_положений_2026';out.mkdir(exist_ok=True)
projects=copy.deepcopy(json.loads((prev/'projects.json').read_text())['projects']);pdfs=list((base/'regulations_extracted').glob('*.pdf'))
# Verified where the PDF contains substantive, selectable Russian text, and the cited clause has been read.
# Format: (project_id, YYYY-MM-DD, description_fragment): (PDF page, clause)
proof={
(2,'2026-10-14','Заявка «От идеи к делу»'):('16','Приложение № 5, пп. 1.2.1, 2.1–2.2'),
(2,'2026-10-15','Задание «От идеи к делу» по PDF'):('16','Приложение № 5, п. 2.2'),
(2,'2026-12-03','Заявка «Территория творчества»'):('10','Приложение № 2, пп. 1.2.1, 2.2'),
(2,'2026-12-15','Окончание основного этапа «Территория творчества»'):('10–11','Приложение № 2, п. 1.2.2, 3.1 — окончание основного этапа, НЕ общий срок задания'),
(2,'2026-12-30','Заявка «Семейные маршруты по Кеми с Первыми»'):('9','Приложение № 1, пп. 1.2.1, 2.2'),
(11,'2026-10-22','Заявка / мотивация'):('6, 8–9','Разделы 6–7, п. 7.2'),
(11,'2026-11-09','Два сертификата обучения'):('6–10','Разделы 6 и 8'),
(12,'2026-10-23','Заявка наставника и муниципальный отбор'):('6, 8','пп. 5.6, 7.2, 8.2'),
(12,'2026-10-31','Завершить состав команды в ЛК'):('6','п. 5.6 — реферальная ссылка и кнопка «Отправить»'),
(17,'2026-10-31','Регистрация на мастер-классы'):('4–5','пп. 5.2.1, 6.2 — заявочная кампания; п. 7.2 — проведение мастер-классов'),
(19,'2026-11-01','Заявка на региональную премию'):('11','Редакция 2, пп. 6.2–6.3.1'),
(23,'2026-11-09','Предложение темы года и эссе'):('6, 8','пп. 5, 6.2.1; время 23:59 МСК'),
(32,'2026-12-10','Заявка «Учись с Первыми»'):('7','п. 5.6 — заявка в цикл очных муниципальных мероприятий'),
(33,'2026-12-15','Заявка IV квартала семейного сообщества'):('5, 8–9','пп. 4.4–4.5, 9.2'),
(41,'2026-12-30','Заявка на региональные тематические смены'):('4, 6','п. 4 и пп. 5.2, 6.2 — общий набор; даты смен отдельно'),
(43,'2026-12-30','Заявка на церемонии вступления'):('3–4','Раздел «Условия участия», «Порядок проведения» — общий период'),
(49,'2027-02-01','Заявка и конкурсная работа'):('9–11','пп. 6.2.1, 7.2, 7.4; конкурсные задания до 23:59 МСК'),
}
# Cases with prose that must not be passed off as an actionable application deadline.
fix_stages={
 2:{'2026-12-15':'Окончание основного этапа «Территория творчества»'},
 12:{'2026-10-23':'Заявка наставника и муниципальный отбор','2026-10-31':'Завершить состав команды в ЛК'},
 17:{'2026-10-31':'Регистрация на мастер-классы'},
 32:{'2026-12-10':'Заявка «Учись с Первыми»'},
 33:{'2026-12-15':'Заявка IV квартала семейного сообщества'},
 41:{'2026-12-30':'Заявка на региональные тематические смены'},
 43:{'2026-12-30':'Заявка на церемонии вступления'},
}
newstages={
 2:[{'date':'2026-12-30','title':'Заявка «Семейные маршруты по Кеми с Первыми»','phase':'application','calendar':True}],
 12:[],
 17:[],
 33:[],
 41:[],
 43:[],
}
fixed_discrepancy={
 2:'По Приложению № 5 PDF заявка «От идеи к делу» закрывается 14.10, а вложенное задание — 15.10: это разные действия. Для «Территории творчества» 15.12 — конец основного этапа, а не последний день подачи заявки. «Семейные маршруты по Кеми с Первыми» имеют свой срок регистрации 30.12.',
 12:'В разделе 5.6 прямо установлены разные даты: до 23 октября наставник подаёт заявку и проходит муниципальный этап; до 31 октября участники присоединяются по ссылке и наставник завершает состав. Срок 31 октября не продлевает муниципальный этап.',
 17:'По пп. 5.2.1 и 6.2 заявки предусмотрены до 31 октября, одновременно мастер-классы идут до 31 октября по п. 7.2. Это общее предельное окно, а не подтверждение наличия мастер-класса в вашем муниципалитете.',
 19:'В архиве два разных положения; для карточки применена более новая редакция 2 (PDF 177). Заявка/портфолио до 1 ноября (пп. 6.2–6.3.1). Состав образовательного ПО и другие условия в новой редакции требуют дополнительной проверки организатора.',
 32:'Положение п. 5.6 допускает заявки на цикл «Учись с Первыми» до 10 декабря, но соседние разделы содержат завершившиеся ранее потоки и слёты. 10 декабря — не дата заявки на прошедший июльский слёт; расписание муниципального потока определяет местное отделение.',
 33:'В региональном PDF 15 декабря обозначено и окончанием проекта, и сроком регистрации/выполнения мероприятий IV квартала. Не распространять этот срок на I–III кварталы.',
 41:'30 декабря — общая граница набора в региональный проект, а не доступная дата отдельной лагерной смены. Места, возраст, реальные даты и медицинские условия проверяются для каждой смены.',
 42:'30 декабря — конец периода проекта, а не конкретное задание или дата заявки; исключено из календаря действий.',
 43:'Заявки допускаются до 30 декабря по региональной программе, но сама церемония проводится в назначенные организатором дни; 30 декабря не гарантирует приглашения на ближайшее посвящение.',
}
# Add stage with multiple meaningful dates to distinguish direct quotation and action.
for p in projects:
 pid=p['id'];docs=[]
 for d in p['documents']:
  b=d['url'].split('/')[-1];f=next((q for q in pdfs if q.name.endswith(b)),None)
  if f:
   pdf=fitz.open(f);t=''.join(page.get_text() for page in pdf)
   substantive=sum(len(page.get_text())>400 for page in pdf) >= max(2,len(pdf)*.25)
   docs.append({'file':f.name,'pages':len(pdf),'text_available':bool(substantive),'text_chars':len(t),'url':d['url']})
 p['pdfAudit']=docs
 p['pdfReview']='нет PDF в архиве' if not docs else ('PDF с текстом; проверены конкретные пункты' if any(d['text_available'] for d in docs) else 'PDF преимущественно скан: автоматическая сверка ограничена')
 if pid in fixed_discrepancy:p['discrepancy']=fixed_discrepancy[pid]
 if pid in fix_stages:
  for s in p['stages']:
   if s['date'] in fix_stages[pid]:s['title']=fix_stages[pid][s['date']]
 if pid==12:
  for s in p['stages']:
   if s['date']=='2026-10-31':s['calendar']=True;s['phase']='task';s['quality']='codex'
 if pid==17:
  for s in p['stages']:
   if s['date']=='2026-10-31':s['phase']='application'
 if pid==32:
  for s in p['stages']:
   if s['date']=='2026-12-10':s['phase']='application';s['calendar']=True
 if pid==33:
  for s in p['stages']:
   if s['date']=='2026-12-15':s['phase']='application';s['calendar']=True
 if pid==41:
  for s in p['stages']:
   if s['date']=='2026-12-30':s['phase']='application';s['calendar']=True
 if pid==42:
  for s in p['stages']:
   if s['date']=='2026-12-30':s['calendar']=False
 if pid==43:
  for s in p['stages']:
   if s['date']=='2026-12-30':s['phase']='application';s['calendar']=True
 if pid==14: # registration until date of conference not to advertise without a confirmed form
  for s in p['stages']:
   s['calendar']=False;s['quality']='conflict'
 if pid==7:
  for s in p['stages']:
   if s['date']=='2026-10-18':s['calendar']=False
 if pid==22:
  for s in p['stages']:s['calendar']=False
 if pid in newstages:
  for s in newstages[pid]:p['stages'].append({'time':'','quality':'codex',**s})
 for s in p['stages']:
  match=proof.get((pid,s['date'],s['title']))
  if match:
   s['quality']='pdf';s['evidence']='PDF '+(docs[0]['file'] if docs else '?')+', с. '+match[0]+', '+match[1]
   s['source']='PDF из архива: '+(docs[0]['file'] if docs else '')
  elif s['quality']=='published':
   s['evidence']='Подтверждено публичной публикацией; PDF с датой пока не прочитан'
  elif docs and not any(d['text_available'] for d in docs):
   s['quality']='scan' if s['quality'] not in {'conflict','published'} else s['quality']
   s['evidence']='PDF в архиве представлен графическим сканом. Дата перенесена из разбора Codex; нужна визуальная проверка пункта и актуальной формы.'
  elif not docs:
   s['quality']='missing' if s['quality'] not in {'conflict','published'} else s['quality']
   s['evidence']='Подходящий PDF отсутствует в архиве; значение из обзора Codex/публикации.'
  else:
   s['evidence']='Проверка этой отдельной даты по PDF не завершена; условие из обзора Codex.'
 # Fix duplicate project stage contradictions: don't assert 15 Dec task deadline for project2
 if pid==2:
  for s in p['stages']:
   if s['date']=='2026-12-15':s['phase']='project_end';s['calendar']=False
 # Restore dates first, but never assign nextStage from a project end.
 p['stages'].sort(key=lambda s:(s['date'],s['title']))
 nexts=[s for s in p['stages'] if s['calendar'] and s['date']>='2026-10-09' and s['phase'] in {'application','task'}]
 p['nextStage']=min(nexts,key=lambda s:s['date']) if nexts else None
 p['auditStatus']='сверены конкретные сроки по PDF' if any(s['quality']=='pdf' for s in p['stages']) else ('сверено по публикации' if p['sourcesPublic'] else 'требует сверки')
# Technical pitfall: PDF 17 actually says registration until Oct31; direct text validated.

cleanEvents=[]
for p in projects:
 for s in p['stages']:
  if s['calendar']:
   cleanEvents.append({'id':p['id'],'date':s['date'],'title':s['title'],'time':s.get('time',''),'quality':s['quality'],'phase':s['phase'],'project':p['title'],'evidence':s.get('evidence','')})
cleanEvents.sort(key=lambda e:(e['date'],e['id']))
result={'asOf':'2026-10-09','newBuild':'2026-10-09','projects':projects,'events':cleanEvents,'review':'83 архивных PDF; непосредственно сопоставлены указанные ниже этапы; часть PDF — сканы, без полной проверяемости'}
(out/'projects.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
with (out/'Реестр_сроков_с_источниками.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['№','Проект','Вид этапа','Дата','Время МСК','Что именно до этой даты','Статус','Основание: PDF и пункт','В календаре','Противоречия/оговорки','Файл PDF в архиве','Ссылка на положение'])
 for p in projects:
  ds=p['pdfAudit'];
  for s in p['stages']:
   w.writerow([p['id'],p['title'],s['phase'],s['date'],s.get('time',''),s['title'],s['quality'],s['evidence'],'Да' if s['calendar'] else 'Нет',p['discrepancy'],'; '.join(v['file'] for v in ds),p['documents'][0]['url'] if p['documents'] else ''])
with (out/'Статус_проверки_PDF.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f,delimiter=';');w.writerow(['№','Проект','Наличие PDF','Тип документа','Статус сверки','Количество непосредственно подтверждённых этапов','Файлы в архиве'])
 for p in projects:
  w.writerow([p['id'],p['title'],'да' if p['pdfAudit'] else 'нет',p['pdfReview'],p['auditStatus'],sum(s['quality']=='pdf' for s in p['stages']),'; '.join(v['file'] for v in p['pdfAudit'])])
# Reuse previously tested UI and only replace embedded data + provenance labels.
old=(prev/'index.html').read_text(encoding='utf-8')
jsonval=json.dumps(result,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
new=re.sub(r'(<script id="siteData" type="application/json">).*?(</script>)',lambda m:m.group(1)+jsonval+m.group(2),old,count=1,flags=re.S)
new=new.replace('Уточнённая структура сроков • 09.10.2026','PDF-аудит • 09.10.2026')
new=new.replace('53 направления из обзора Codex. Заявки, задания и проведение мероприятий разделены по этапам, а неподтверждённые даты помечены отдельно.','53 направления Движения Первых. Даты разделены по видам, подтверждённые сроки сопровождаются страницей PDF из архива, сканы без текстового слоя помечены.')
new=new.replace('На календаре только действия с датой: заявка, задания и отдельные учебные этапы. Даты реализации проектов не выдаются за сроки заявки.','Календарь с конкретными действиями. Даты, сверенные с читаемыми PDF, отличаются от непроверенных сроков, а периоды реализации не выданы за заявочные дедлайны.')
new=new.replace('Зелёные сроки дополнительно сверены с датированными публичными публикациями, серые взяты из обзора Codex, оранжевые содержат противоречие. Проверка доступности формы в реальном времени отсутствует.','Зелёные сроки сверены с конкретной страницей PDF или публикацией; серые — из обзора Codex/сканов, оранжевые — с расхождением. Фактическое состояние формы в реальном времени не проверено.')
new=new.replace('Даты по 53 карточкам не прошли сплошную независимую онлайн-проверку.','Не все 53 проекта подтверждены: многие PDF являются сканами без текстового слоя.')
new=new.replace('Противоречия</div>','Оговорки по срокам</div>')
new=new.replace('разногласия источников','случаи с пояснениями')
new=new.replace('⚠ Спорные даты','⚠ Оговорки по срокам')
new=new.replace('⚠ Расхождение','⚠ Есть пояснение')
new=new.replace('Сведения по 53 карточкам не прошли сплошную независимую онлайн-проверку.','Не все 53 проекта подтверждены: многие PDF являются сканами без текстового слоя.')
new=new.replace('4 даты дополнительно сопоставлены с опубликованными материалами; остальные не подтверждены в реальном времени.', '17 этапов сверены с указанными страницами PDF и ещё 4 даты — с публичными публикациями. Для остальных сроков необходима ручная проверка сканов и действующих форм.')
new=new.replace('только четырьмя датами с публичным подтверждением','сроками, подтверждёнными читаемым PDF либо независимой публикацией')
new=new.replace('только сроки, подтверждённые датированными публичными источниками.', 'только сроки, проверенные по PDF из архива или публикации.')
new=new.replace('только сроки, corroborированные датированными публичными источниками.','только даты, проверенные по страницам PDF или публикации.')
new=new.replace('Только аналитический обзор','Нужно проверить по PDF или форме')
new=new.replace('q===\'published\'?\'Дата подтверждена публикацией\':q===\'conflict\'?\'Противоречие или спорная дата\':\'Только аналитический обзор\'',"q==='pdf'?'Сверено с PDF из архива':q==='published'?'Сверено с публикацией':q==='scan'?'PDF-скан: дата из обзора':q==='missing'?'Положение не приложено':q==='conflict'?'Противоречие или спорная дата':'Не проверено по PDF'")
# preceding replacement may have changed fallback string; ensure full function regex
new=re.sub(r'function statusText\(q\)\{.*?\}',"function statusText(q){return q==='pdf'?'Сверено с PDF из архива':q==='published'?'Сверено с публикацией':q==='scan'?'PDF-скан: дата из обзора':q==='missing'?'Нет положения в архиве':q==='conflict'?'Спорная дата':'Не проверено по PDF'}",new,count=1)
new=re.sub(r'function alertText\(q\)\{.*?\}',"function alertText(q){return q==='pdf'?'PDF проверен':q==='published'?'Публикация':q==='scan'?'Скан: не сверено':q==='missing'?'Нет PDF':q==='conflict'?'Уточнить дату':'Из обзора Codex'}",new,count=1)
new=re.sub(r'function sourceLabel\(p\)\{.*?\}',"function sourceLabel(p){return p.auditStatus==='сверены конкретные сроки по PDF'?'Есть сроки, сверенные с PDF':p.discrepancy?'Есть оговорки':'Сроки требуют проверки'}",new,count=1)
# Add traceable per-stage page/clause citation.
new=new.replace('<span class="flag ${s.quality}">${esc(statusText(s.quality))}</span></div></div>`','<span class="flag ${s.quality}">${esc(statusText(s.quality))}</span>${s.evidence?`<small class="stage-evidence">${esc(s.evidence)}</small>`:""}</div></div>`')
new=new.replace('Серый — из исходного обзора Codex (09.10.2026). Зелёный — дополнительно подтверждён датированной публичной публикацией. Оранжевый — противоречие, неполное положение или дата рекомендательного характера. Зелёный не означает, что форма заявки сейчас открыта.','Зелёный — срок сверён с конкретным пунктом PDF из архива либо официальной публикацией. Серый — пересказ Codex или PDF-скан, который ещё нужно проверить визуально. Оранжевый — противоречие. Проверенный документ не означает, что форма сейчас открыта.')
new=new.replace('<section class="detail-section"><h3>Формулировка срока в Codex</h3>','<section class="detail-section"><h3>Первоначальный обзор Codex — для сравнения</h3>')
new=new.replace("(include||e.quality==='published')","(include||e.quality==='published'||e.quality==='pdf')")
new=new.replace("(e.quality==='published'?'':' [УТОЧНИТЬ]')","(['published','pdf'].includes(e.quality)?'':' [УТОЧНИТЬ]')")
new=new.replace("q==='published'", "q==='published'")
# UI notes and trace evidence
new=new.replace('Публикация подтверждает срок', 'Указано основание даты')
new=new.replace('✓ Публикация подтверждает срок', '✓ Есть проверенные даты')
new=new.replace("if(state.fast.has('published')&&!p.sourcesPublic.length)return false;","if(state.fast.has('published')&&!p.sourcesPublic.length&&!p.stages.some(s=>s.quality==='pdf'))return false;")
new=new.replace('Не все положения доступны для чтения вне платформы.','В большинстве PDF без текстового слоя содержание нельзя автоматически проверить. Для уверенности сверьте страницу и активную форму на платформе.')
# Improve sorting: internal calendar title; self contained CSS.
new=new.replace('</style>','''\n.flag.pdf,.evt.pdf{background:#E6F4EA!important;color:#176C40!important;border-color:#B4DBC4!important}
.flag.scan,.flag.missing{background:#EDF0F5!important;color:#525F70!important;border-color:#D9E0E9!important}
.stage-evidence{display:block;margin-top:6px;line-height:1.45;color:var(--muted,#627083);font-size:12px;overflow-wrap:anywhere}
</style>''',1)
(out/'index.html').write_text(new,encoding='utf-8')
# Count evidence
cnt=collections.Counter(s['quality'] for p in projects for s in p['stages']);doccounter=collections.Counter(p['pdfReview'] for p in projects)
readme=f'''# Навигатор проектов Первых — сверка с приложенными положениями (09.10.2026)

Откройте `index.html` в браузере. Интернет не нужен для каталога, поиска, фильтров, календаря и личного плана. Для переходов на официальные карточки интернет потребуется.

## Источники и достоверность

Из `regulations.rar` распаковано **83 PDF**. Они содержат повторы/разные редакции, а не 83 разных проекта. Не все PDF содержат машинно читаемый текст: многие — сканированные изображения. Поэтому сплошную сверку всех 53 карточек достоверной назвать нельзя.

Статусы в карточках: **«PDF проверен»** — конкретная дата проверена по читаемому тексту вложенного PDF и указаны страница и пункт; **«Публикация»** — дополнительное независимое публичное подтверждение из предыдущего аудита; **«Скан: не сверено»** — PDF вложен, но дату можно пока прочитать только в аналитическом обзоре Codex; **«Из обзора»** — прямой проверки даты нет; **«Уточнить дату»** — внутреннее противоречие либо несовпадение внешних источников. Это **не проверка доступности формы** в личном кабинете.

В том числе для программы «Первый танцевальный» уточнено, что срок подачи заявки 31.10 действительно подтверждается пп. 5.2.1 и 6.2 PDF, одновременно завершается период мастер-классов (п. 7.2). Это два разных смысла одной даты.

Обязательно проверяйте *последнюю редакцию* положения и статус формы перед отправкой. Календарь .ics по умолчанию выгружает только PDF-проверенные или публично подтвержденные сроки. Остальные можно включить явно.

## Состав
- `index.html` — готовый интерактивный сайт (один автономный файл).
- `projects.json` — полная база 53 карточек и {len(cleanEvents)} событий.
- `Реестр_сроков_с_источниками.csv` — детальные сроки с страницами/пунктами, уровнем подтверждения и статусом календаря.
- `Статус_проверки_PDF.csv` — покрытие 53 проектов архивными документами и статус читаемости.

## Сводка
- Этапы по статусу: {dict(cnt)}.
- Проекты по типу вложений: {dict(doccounter)}.
- Количество подтверждённых по PDF дат: {cnt['pdf']}.

Веб-сайт не является официальным сайтом Движения Первых. Его база статична на 09.10.2026 и не проверяет формы в режиме реального времени.
'''
(out/'README.md').write_text(readme,encoding='utf-8')
# Save reproducible script
import shutil
shutil.copy(__file__,out/'build.py')
archive=base/'Навигатор_Первых_сверка_по_положениям_2026.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(out.glob('*')):
  if f.is_file():z.write(f,f.name)
print('SUMMARY',len(projects),len(cleanEvents),dict(cnt),dict(doccounter));print('FILES',out,archive,archive.stat().st_size)
