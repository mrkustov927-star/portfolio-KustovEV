@echo off
cd /d "%~dp0"
if not exist .env copy .env.example .env >nul
python -m vk_monitor init
if errorlevel 1 goto :error
python -m vk_monitor run
goto :eof
:error
echo.
echo Не удалось запустить мониторинг. Убедитесь, что установлен Python 3.11 или новее.
pause

