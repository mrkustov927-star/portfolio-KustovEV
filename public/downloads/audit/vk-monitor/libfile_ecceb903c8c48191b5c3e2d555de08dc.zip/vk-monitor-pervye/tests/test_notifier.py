from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest

from vk_monitor.database import Database
from vk_monitor.notifier import Notifier, build_delivery_chunks
from vk_monitor.settings import parse_notify_peer_ids


class FakeMessenger:
    def __init__(self, fail: bool = False):
        self.fail = fail
        self.sent: list[tuple[int, str]] = []

    def send_message(self, peer_id: int, message: str):
        if self.fail:
            raise RuntimeError("тестовая ошибка")
        self.sent.append((peer_id, message))
        return len(self.sent)


class NotifierTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "notify.db")
        self.db.init()
        self.db.add_community("test", "Тестовое сообщество", "own")
        self.db.add_query("hashtag", "#ПервыеКемь", "#ПервыеКемь", "Медиа", "Медиа")
        community = self.db.list_communities()[0]
        query = self.db.list_queries()[0]
        self.post_id = self.db.upsert_post(
            community["id"],
            {
                "id": 7,
                "owner_id": -100,
                "date": int(datetime(2026, 9, 8, 8, tzinfo=timezone.utc).timestamp()),
                "text": "Новая публикация о событии #ПервыеКемь",
                "repost_text": "",
                "is_repost": False,
                "source_url": "https://vk.ru/wall-100_7",
                "likes": 2,
                "comments": 1,
                "reposts": 0,
                "views": 25,
                "raw": {},
            },
        )
        self.db.replace_matches(
            self.post_id,
            [{"query_id": query["id"], "evidence": "#первыекемь"}],
        )
        scan_id = self.db.start_scan(1)
        self.db.finish_scan(scan_id, "ok", 1, 1, 1)
        self.settings = SimpleNamespace(
            notify_token="secret",
            notify_peer_ids=(123456,),
            notify_empty=True,
            notify_max_posts=50,
            notification_configured=True,
            notification_partially_configured=False,
            api_version="5.199",
            timezone="Europe/Moscow",
        )

    def tearDown(self):
        self.tmp.cleanup()

    def test_peer_aliases(self):
        self.assertEqual(
            parse_notify_peer_ids("user:123, chat:7, peer:2000000008,123"),
            (123, 2_000_000_007, 2_000_000_008),
        )
        with self.assertRaises(ValueError):
            parse_notify_peer_ids("chat:wrong")

    def test_delivery_is_not_repeated(self):
        messenger = FakeMessenger()
        notifier = Notifier(self.db, self.settings, messenger)
        first = notifier.run(require_config=True)
        second = notifier.run(require_config=True)

        self.assertEqual(first.posts_sent, 1)
        self.assertEqual(first.messages_sent, 1)
        self.assertEqual(second.posts_sent, 0)
        self.assertEqual(second.messages_sent, 0)
        self.assertEqual(len(messenger.sent), 1)
        self.assertIn("https://vk.ru/wall-100_7", messenger.sent[0][1])
        self.assertIn("#ПервыеКемь", messenger.sent[0][1])

    def test_failed_delivery_is_left_pending(self):
        result = Notifier(self.db, self.settings, FakeMessenger(fail=True)).run()
        self.assertEqual(result.posts_sent, 0)
        self.assertEqual(len(result.errors), 1)
        self.assertEqual(self.db.count_unnotified_matched_posts(123456), 1)

    def test_chunks_stay_below_configured_limit(self):
        rows = self.db.list_unnotified_matched_posts(123456, 50)
        chunks = build_delivery_chunks(
            rows,
            pending_total=1,
            scan=self.db.list_scans(1)[0],
            timezone_name="Europe/Moscow",
            report_date="2026-09-08",
            max_chars=600,
        )
        self.assertTrue(chunks)
        self.assertTrue(all(len(chunk.text) <= 600 for chunk in chunks))


if __name__ == "__main__":
    unittest.main()
