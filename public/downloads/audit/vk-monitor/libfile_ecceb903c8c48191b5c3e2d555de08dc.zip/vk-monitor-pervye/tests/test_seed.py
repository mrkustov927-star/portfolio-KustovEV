from pathlib import Path
import tempfile
import unittest

from vk_monitor.database import Database
from vk_monitor.seed import seed_communities


class SeedTests(unittest.TestCase):
    def test_seed_communities_from_compact_setting(self):
        with tempfile.TemporaryDirectory() as tmp:
            database = Database(Path(tmp) / "seed.db")
            database.init()
            inserted, total = seed_communities(
                database,
                "https://vk.ru/main|Главная группа|own,club123|Школа|primary",
            )
            self.assertEqual((inserted, total), (2, 2))
            rows = database.list_communities()
            self.assertEqual({row["kind"] for row in rows}, {"own", "primary"})


if __name__ == "__main__":
    unittest.main()

