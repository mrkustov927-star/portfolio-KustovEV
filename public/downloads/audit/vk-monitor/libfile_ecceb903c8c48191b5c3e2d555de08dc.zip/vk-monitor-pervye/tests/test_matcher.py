import unittest

from vk_monitor.matcher import extract_hashtags, match_text, normalize


class MatcherTests(unittest.TestCase):
    def test_normalizes_case_and_yo(self):
        self.assertEqual(normalize("  ЁЛКА   желаний "), "елка желаний")

    def test_hashtag_is_exact_and_case_insensitive(self):
        text = "Встречаемся сегодня! #ПервыеКемь #ДвижениеПервых10"
        self.assertTrue(match_text("hashtag", "#первыекемь", text).matched)
        self.assertFalse(match_text("hashtag", "#первые", text).matched)

    def test_cyrillic_hashtags(self):
        self.assertEqual(
            extract_hashtags("#ПервыеКемь, #КемскийОкруг"),
            {"#первыекемь", "#кемскийокруг"},
        )

    def test_phrase_matches_yo_variant(self):
        self.assertTrue(match_text("phrase", "Ёлка желаний", "Елка желаний началась").matched)

    def test_phrase_matches_common_russian_inflection(self):
        result = match_text("phrase", "Зарница 2.0", "Подготовка к этапу Зарницы 2.0")
        self.assertTrue(result.matched)
        self.assertLess(result.confidence, 1.0)

    def test_mention_formats(self):
        for text in (
            "Спасибо @club193878416 за встречу",
            "Спасибо [club193878416|организаторам]",
            "Подробнее: https://vk.ru/club193878416",
        ):
            with self.subTest(text=text):
                self.assertTrue(match_text("mention", "https://vk.ru/club193878416", text).matched)

    def test_word_groups(self):
        text = "Сегодня прошел муниципальный этап игры"
        self.assertTrue(match_text("words_all", "муниципальный этап; игры", text).matched)
        self.assertTrue(match_text("words_any", "районный; муниципальный", text).matched)
        self.assertFalse(match_text("words_all", "региональный; этап", text).matched)


if __name__ == "__main__":
    unittest.main()
