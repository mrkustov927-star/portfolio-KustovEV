from datetime import datetime, timezone
from pathlib import Path
import tempfile
import unittest

from vk_monitor.database import Database
from vk_monitor.reports import export_report_csv


class DatabaseReportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "test.db")
        self.db.init()

    def tearDown(self):
        self.tmp.cleanup()

    def test_post_upsert_is_idempotent_and_export_has_link(self):
        self.db.add_community("test", "Тест", "own")
        community = self.db.list_communities()[0]
        self.db.add_query("hashtag", "#ПервыеКемь", "Первые Кемь", "", "Медиа")
        query = self.db.list_queries()[0]
        post = {
            "id": 7,
            "owner_id": -100,
            "date": int(datetime(2026, 9, 8, tzinfo=timezone.utc).timestamp()),
            "text": "Проверка #ПервыеКемь",
            "repost_text": "",
            "is_repost": False,
            "source_url": "https://vk.ru/wall-100_7",
            "likes": 2,
            "comments": 1,
            "reposts": 0,
            "views": 25,
            "raw": {},
        }
        first_id = self.db.upsert_post(community["id"], post)
        post["views"] = 30
        second_id = self.db.upsert_post(community["id"], post)
        self.assertEqual(first_id, second_id)
        self.db.replace_matches(first_id, [{"query_id": query["id"], "evidence": "#первыекемь"}])
        data = export_report_csv(self.db, "Europe/Moscow").decode("utf-8-sig")
        self.assertIn("https://vk.ru/wall-100_7", data)
        self.assertIn(";30;2;0;1;", data)
        self.assertEqual(len(self.db.list_matched_posts()), 1)


if __name__ == "__main__":
    unittest.main()

