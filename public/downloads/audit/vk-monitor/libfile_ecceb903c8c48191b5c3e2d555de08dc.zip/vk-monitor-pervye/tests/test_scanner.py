from pathlib import Path
from types import SimpleNamespace
import tempfile
import time
import unittest

from vk_monitor.database import Database
from vk_monitor.scanner import Scanner


class FakeVKClient:
    def resolve_group(self, source):
        return {"id": 101, "name": "Тестовое сообщество", "screen_name": source}

    def iter_wall_posts(self, group_id, since_ts, max_pages):
        yield {
            "id": 5,
            "owner_id": -group_id,
            "date": int(time.time()),
            "text": "Сегодня прошёл этап Зарницы 2.0. #ПервыеКемь",
            "repost_text": "",
            "is_repost": False,
            "source_url": "https://vk.ru/wall-101_5",
            "likes": 4,
            "comments": 1,
            "reposts": 0,
            "views": 50,
            "raw": {},
        }


class ScannerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "scan.db")
        self.db.init()
        self.db.add_community("test_group", "", "own")
        self.db.add_query("hashtag", "#ПервыеКемь", "Первые Кемь")
        self.db.add_query("phrase", "Зарница 2.0", "Зарница 2.0", "Зарница 2.0")
        self.settings = SimpleNamespace(
            access_token="not-used-by-fake",
            api_version="5.199",
            link_domain="vk.ru",
            initial_days=30,
            lookback_days=7,
            max_pages_per_community=30,
        )

    def tearDown(self):
        self.tmp.cleanup()

    def test_scan_is_idempotent(self):
        scanner = Scanner(self.db, self.settings, client=FakeVKClient())
        first = scanner.run()
        second = scanner.run()
        self.assertEqual(first.communities_ok, 1)
        self.assertEqual(first.matches_found, 2)
        self.assertEqual(second.matches_found, 2)
        self.assertEqual(self.db.dashboard_stats()["posts"], 1)
        self.assertEqual(len(self.db.list_matched_posts()), 1)


if __name__ == "__main__":
    unittest.main()

