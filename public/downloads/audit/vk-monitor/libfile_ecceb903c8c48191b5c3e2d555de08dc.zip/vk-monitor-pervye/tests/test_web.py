from http.server import ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlencode
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import tempfile
import threading
import unittest

from vk_monitor.cli import add_demo
from vk_monitor.database import Database
from vk_monitor.seed import seed_defaults
from vk_monitor.web import make_handler


class WebSmokeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "web.db")
        self.db.init()
        seed_defaults(self.db)
        add_demo(self.db)
        settings = SimpleNamespace(
            web_password="",
            token_configured=False,
            timezone="Europe/Moscow",
        )
        controller = SimpleNamespace(running=False, last_error="", start=lambda: True)
        self.server = ThreadingHTTPServer(
            ("127.0.0.1", 0), make_handler(self.db, settings, controller)
        )
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.server.server_port}"

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)
        self.tmp.cleanup()

    def test_main_pages_and_export(self):
        for path in ("/health", "/", "/communities", "/queries", "/posts", "/scans"):
            with self.subTest(path=path), urlopen(self.base + path, timeout=3) as response:
                self.assertEqual(response.status, 200)
        with urlopen(self.base + "/", timeout=3) as response:
            body = response.read().decode("utf-8")
            self.assertIn("Мониторинг публикаций ВКонтакте", body)
            self.assertIn("Медиа за", body)
        with urlopen(self.base + "/export.csv", timeout=3) as response:
            report = response.read().decode("utf-8-sig")
            self.assertIn("Сроки проведения", report)
            self.assertIn("Зарница 2.0", report)

    def test_add_community_form(self):
        data = urlencode({"sources": "https://vk.ru/test_school; Тестовая школа\nclub12345", "kind": "primary"}).encode()
        request = Request(self.base + "/communities/add", data=data, method="POST")
        with urlopen(request, timeout=3) as response:
            self.assertEqual(response.status, 200)
        self.assertTrue(any(row["source"] == "https://vk.ru/test_school" for row in self.db.list_communities()))
        self.assertTrue(any(row["source"] == "club12345" for row in self.db.list_communities()))

    def test_health_is_available_when_panel_has_password(self):
        settings = SimpleNamespace(web_password="secret", token_configured=False, timezone="Europe/Moscow")
        controller = SimpleNamespace(running=False, last_error="", start=lambda: True)
        server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.db, settings, controller))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            with urlopen(base + "/health", timeout=3) as response:
                self.assertEqual(response.status, 200)
            with self.assertRaises(HTTPError) as context:
                urlopen(base + "/", timeout=3)
            self.assertEqual(context.exception.code, 401)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
