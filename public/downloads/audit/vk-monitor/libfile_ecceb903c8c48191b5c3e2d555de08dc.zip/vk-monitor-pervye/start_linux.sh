#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Создан файл .env. Добавьте в него VK_ACCESS_TOKEN и запустите скрипт снова."
  exit 1
fi
python3 -m vk_monitor init
exec python3 -m vk_monitor run

