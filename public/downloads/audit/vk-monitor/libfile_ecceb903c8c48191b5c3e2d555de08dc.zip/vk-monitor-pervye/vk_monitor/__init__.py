"""VK Monitor Pervye."""

__version__ = "0.2.0"
