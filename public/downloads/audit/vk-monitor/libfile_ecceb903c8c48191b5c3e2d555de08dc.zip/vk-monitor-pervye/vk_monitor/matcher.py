from __future__ import annotations

from dataclasses import dataclass
import re
import unicodedata


HASHTAG_RE = re.compile(r"(?<![\w#])#[\w.-]+", re.UNICODE)
WORD_RE = re.compile(r"[\w]+", re.UNICODE)
CYRILLIC_RE = re.compile(r"^[а-я]+$", re.IGNORECASE)
RUSSIAN_ENDINGS = tuple(
    sorted(
        {
            "иями", "ями", "ами", "его", "ого", "ему", "ому", "иями",
            "ение", "ения", "ений", "ением", "ениями",
            "ая", "яя", "ою", "ею", "ее", "ие", "ые", "ое",
            "ей", "ий", "ый", "ой", "ем", "им", "ым", "ом",
            "их", "ых", "ую", "юю", "ев", "ов", "ье", "ья",
            "ам", "ям", "ах", "ях", "ию", "ью", "ия", "ья",
            "а", "я", "ы", "и", "ь", "й", "у", "ю", "е", "о",
        },
        key=len,
        reverse=True,
    )
)


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text or "").casefold().replace("ё", "е")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def normalize_hashtag(value: str) -> str:
    value = normalize(value)
    if value and not value.startswith("#"):
        value = "#" + value
    return value


def extract_hashtags(text: str) -> set[str]:
    return {normalize_hashtag(item) for item in HASHTAG_RE.findall(text or "")}


def _tokens(value: str) -> list[str]:
    return [normalize(item) for item in WORD_RE.findall(value) if normalize(item)]


def _light_russian_stem(word: str) -> str:
    """Conservative stemmer for common title inflections, not a linguistic classifier."""
    word = normalize(word)
    if len(word) < 5 or not CYRILLIC_RE.match(word):
        return word
    for ending in RUSSIAN_ENDINGS:
        if word.endswith(ending) and len(word) - len(ending) >= 3:
            return word[: -len(ending)]
    return word


def _contains_stem_sequence(pattern: str, text: str) -> bool:
    pattern_tokens = [_light_russian_stem(item) for item in _tokens(pattern)]
    text_tokens = [_light_russian_stem(item) for item in _tokens(text)]
    if not pattern_tokens or len(pattern_tokens) > len(text_tokens):
        return False
    size = len(pattern_tokens)
    return any(text_tokens[index:index + size] == pattern_tokens for index in range(len(text_tokens) - size + 1))


def _mention_candidates(pattern: str) -> set[str]:
    raw = normalize(pattern).strip(" /@")
    for prefix in ("https://", "http://"):
        if raw.startswith(prefix):
            raw = raw[len(prefix):]
    for domain in ("vk.ru/", "vk.com/", "m.vk.com/"):
        if raw.startswith(domain):
            raw = raw[len(domain):]
    raw = raw.split("?", 1)[0].split("#", 1)[0].strip("/")
    candidates = {raw} if raw else set()
    if raw.startswith("club") and raw[4:].isdigit():
        candidates.add("public" + raw[4:])
    if raw.startswith("public") and raw[6:].isdigit():
        candidates.add("club" + raw[6:])
    return candidates


@dataclass(frozen=True, slots=True)
class MatchResult:
    matched: bool
    evidence: str = ""
    confidence: float = 1.0


def match_text(kind: str, pattern: str, text: str) -> MatchResult:
    normalized_text = normalize(text)
    normalized_pattern = normalize(pattern)

    if kind == "hashtag":
        target = normalize_hashtag(pattern)
        matched = target in extract_hashtags(text)
        return MatchResult(matched, target if matched else "")

    if kind == "phrase":
        exact = bool(normalized_pattern and normalized_pattern in normalized_text)
        if exact:
            return MatchResult(True, pattern, 1.0)
        inflected = _contains_stem_sequence(pattern, text)
        return MatchResult(inflected, pattern if inflected else "", 0.88 if inflected else 1.0)

    if kind == "mention":
        for candidate in _mention_candidates(pattern):
            escaped = re.escape(candidate)
            forms = (
                rf"@{escaped}(?![\w])",
                rf"\[{escaped}\|",
                rf"(?:vk\.ru|vk\.com)/{escaped}(?![\w])",
            )
            if any(re.search(form, normalized_text) for form in forms):
                return MatchResult(True, candidate)
        return MatchResult(False)

    separators = re.split(r"[,;\n]+", pattern)
    parts = [normalize(item) for item in separators if normalize(item)]
    if not parts:
        parts = _tokens(pattern)
    if kind == "words_any":
        hits = [item for item in parts if item in normalized_text]
        return MatchResult(bool(hits), ", ".join(hits))
    if kind == "words_all":
        hits = [item for item in parts if item in normalized_text]
        return MatchResult(len(hits) == len(parts) and bool(parts), ", ".join(hits))

    raise ValueError(f"Неизвестный тип запроса: {kind}")


def searchable_post_text(post: dict) -> str:
    parts = [str(post.get("text") or "")]
    repost_text = str(post.get("repost_text") or "")
    if repost_text:
        parts.append(repost_text)
    return "\n".join(parts)
