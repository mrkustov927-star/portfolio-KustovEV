from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import json
import sqlite3


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS communities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL UNIQUE,
    vk_group_id INTEGER UNIQUE,
    screen_name TEXT,
    name TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL DEFAULT 'other',
    enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
    created_at TEXT NOT NULL,
    last_scan_ts INTEGER,
    last_scan_at TEXT,
    last_error TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS queries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL CHECK (kind IN ('hashtag', 'phrase', 'mention', 'words_any', 'words_all')),
    pattern TEXT NOT NULL,
    label TEXT NOT NULL,
    project TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
    created_at TEXT NOT NULL,
    UNIQUE(kind, pattern, project)
);

CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
    owner_id INTEGER NOT NULL,
    vk_post_id INTEGER NOT NULL,
    published_ts INTEGER NOT NULL,
    text TEXT NOT NULL DEFAULT '',
    repost_text TEXT NOT NULL DEFAULT '',
    is_repost INTEGER NOT NULL DEFAULT 0 CHECK (is_repost IN (0, 1)),
    source_url TEXT NOT NULL,
    likes INTEGER NOT NULL DEFAULT 0,
    comments INTEGER NOT NULL DEFAULT 0,
    reposts INTEGER NOT NULL DEFAULT 0,
    views INTEGER NOT NULL DEFAULT 0,
    review_status TEXT NOT NULL DEFAULT 'new' CHECK (review_status IN ('new', 'reviewed', 'excluded')),
    title_override TEXT NOT NULL DEFAULT '',
    project_override TEXT NOT NULL DEFAULT '',
    category_override TEXT NOT NULL DEFAULT '',
    note TEXT NOT NULL DEFAULT '',
    collected_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    raw_json TEXT NOT NULL DEFAULT '{}',
    UNIQUE(owner_id, vk_post_id)
);

CREATE TABLE IF NOT EXISTS matches (
    post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    query_id INTEGER NOT NULL REFERENCES queries(id) ON DELETE CASCADE,
    evidence TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 1.0,
    detected_at TEXT NOT NULL,
    PRIMARY KEY (post_id, query_id)
);

CREATE TABLE IF NOT EXISTS notifications (
    post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    peer_id INTEGER NOT NULL,
    sent_at TEXT NOT NULL,
    PRIMARY KEY (post_id, peer_id)
);

CREATE TABLE IF NOT EXISTS notification_runs (
    peer_id INTEGER NOT NULL,
    report_date TEXT NOT NULL,
    sent_at TEXT NOT NULL,
    posts_sent INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (peer_id, report_date)
);

CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL CHECK (status IN ('running', 'ok', 'partial', 'error')),
    communities_total INTEGER NOT NULL DEFAULT 0,
    communities_ok INTEGER NOT NULL DEFAULT 0,
    posts_seen INTEGER NOT NULL DEFAULT 0,
    matches_found INTEGER NOT NULL DEFAULT 0,
    error TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_posts_published ON posts(published_ts DESC);
CREATE INDEX IF NOT EXISTS idx_posts_community ON posts(community_id, published_ts DESC);
CREATE INDEX IF NOT EXISTS idx_matches_query ON matches(query_id);
CREATE INDEX IF NOT EXISTS idx_notifications_peer ON notifications(peer_id, sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_scans_started ON scans(started_at DESC);
"""


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    @contextmanager
    def connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def init(self) -> None:
        with self.connect() as conn:
            conn.executescript(SCHEMA)

    def add_community(self, source: str, name: str = "", kind: str = "other") -> bool:
        source = source.strip()
        if not source:
            raise ValueError("Укажите ссылку, короткое имя или ID сообщества")
        if kind not in {"own", "primary", "city", "media", "other"}:
            raise ValueError("Недопустимый тип сообщества")
        with self.connect() as conn:
            cur = conn.execute(
                """INSERT OR IGNORE INTO communities(source, name, kind, created_at)
                   VALUES (?, ?, ?, ?)""",
                (source, name.strip(), kind, utc_now_iso()),
            )
            return cur.rowcount > 0

    def list_communities(self, enabled_only: bool = False):
        where = "WHERE enabled = 1" if enabled_only else ""
        with self.connect() as conn:
            return conn.execute(
                f"SELECT * FROM communities {where} ORDER BY enabled DESC, kind, name, source"
            ).fetchall()

    def toggle_community(self, community_id: int) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE communities SET enabled = CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id = ?",
                (community_id,),
            )

    def update_community_resolution(self, community_id: int, group: dict) -> None:
        with self.connect() as conn:
            conn.execute(
                """UPDATE communities
                   SET vk_group_id = ?, screen_name = ?, name = CASE WHEN name = '' THEN ? ELSE name END,
                       last_error = ''
                   WHERE id = ?""",
                (group["id"], group.get("screen_name", ""), group.get("name", ""), community_id),
            )

    def update_community_scan(self, community_id: int, scan_ts: int, error: str = "") -> None:
        with self.connect() as conn:
            conn.execute(
                """UPDATE communities SET last_scan_ts = ?, last_scan_at = ?, last_error = ?
                   WHERE id = ?""",
                (scan_ts, utc_now_iso(), error[:1000], community_id),
            )

    def set_community_error(self, community_id: int, error: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE communities SET last_error = ? WHERE id = ?",
                (error[:1000], community_id),
            )

    def add_query(
        self,
        kind: str,
        pattern: str,
        label: str = "",
        project: str = "",
        category: str = "",
    ) -> bool:
        if kind not in {"hashtag", "phrase", "mention", "words_any", "words_all"}:
            raise ValueError("Недопустимый тип запроса")
        pattern = pattern.strip()
        if not pattern:
            raise ValueError("Поисковый запрос не может быть пустым")
        label = label.strip() or pattern
        with self.connect() as conn:
            cur = conn.execute(
                """INSERT OR IGNORE INTO queries
                   (kind, pattern, label, project, category, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (kind, pattern, label, project.strip(), category.strip(), utc_now_iso()),
            )
            return cur.rowcount > 0

    def list_queries(self, enabled_only: bool = False):
        where = "WHERE enabled = 1" if enabled_only else ""
        with self.connect() as conn:
            return conn.execute(
                f"SELECT * FROM queries {where} ORDER BY enabled DESC, kind, label"
            ).fetchall()

    def toggle_query(self, query_id: int) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE queries SET enabled = CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id = ?",
                (query_id,),
            )

    def start_scan(self, communities_total: int) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO scans(started_at, status, communities_total) VALUES (?, 'running', ?)",
                (utc_now_iso(), communities_total),
            )
            return int(cur.lastrowid)

    def finish_scan(
        self,
        scan_id: int,
        status: str,
        communities_ok: int,
        posts_seen: int,
        matches_found: int,
        error: str = "",
    ) -> None:
        with self.connect() as conn:
            conn.execute(
                """UPDATE scans SET finished_at = ?, status = ?, communities_ok = ?,
                   posts_seen = ?, matches_found = ?, error = ? WHERE id = ?""",
                (
                    utc_now_iso(),
                    status,
                    communities_ok,
                    posts_seen,
                    matches_found,
                    error[:4000],
                    scan_id,
                ),
            )

    def upsert_post(self, community_id: int, post: dict) -> int:
        now = utc_now_iso()
        raw_json = json.dumps(post.get("raw", {}), ensure_ascii=False, separators=(",", ":"))
        with self.connect() as conn:
            conn.execute(
                """INSERT INTO posts(
                       community_id, owner_id, vk_post_id, published_ts, text, repost_text,
                       is_repost, source_url, likes, comments, reposts, views,
                       collected_at, updated_at, raw_json
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(owner_id, vk_post_id) DO UPDATE SET
                       community_id = excluded.community_id,
                       published_ts = excluded.published_ts,
                       text = excluded.text,
                       repost_text = excluded.repost_text,
                       is_repost = excluded.is_repost,
                       source_url = excluded.source_url,
                       likes = excluded.likes,
                       comments = excluded.comments,
                       reposts = excluded.reposts,
                       views = excluded.views,
                       updated_at = excluded.updated_at,
                       raw_json = excluded.raw_json""",
                (
                    community_id,
                    int(post["owner_id"]),
                    int(post["id"]),
                    int(post["date"]),
                    str(post.get("text") or ""),
                    str(post.get("repost_text") or ""),
                    int(bool(post.get("is_repost"))),
                    str(post["source_url"]),
                    int(post.get("likes", 0)),
                    int(post.get("comments", 0)),
                    int(post.get("reposts", 0)),
                    int(post.get("views", 0)),
                    now,
                    now,
                    raw_json,
                ),
            )
            row = conn.execute(
                "SELECT id FROM posts WHERE owner_id = ? AND vk_post_id = ?",
                (int(post["owner_id"]), int(post["id"])),
            ).fetchone()
            return int(row["id"])

    def replace_matches(self, post_id: int, matches: list[dict]) -> None:
        with self.connect() as conn:
            conn.execute("DELETE FROM matches WHERE post_id = ?", (post_id,))
            if matches:
                conn.executemany(
                    """INSERT INTO matches(post_id, query_id, evidence, confidence, detected_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    [
                        (
                            post_id,
                            int(item["query_id"]),
                            str(item.get("evidence", "")),
                            float(item.get("confidence", 1.0)),
                            utc_now_iso(),
                        )
                        for item in matches
                    ],
                )

    def review_post(
        self,
        post_id: int,
        status: str,
        title: str = "",
        project: str = "",
        category: str = "",
        note: str = "",
    ) -> None:
        if status not in {"new", "reviewed", "excluded"}:
            raise ValueError("Недопустимый статус проверки")
        with self.connect() as conn:
            conn.execute(
                """UPDATE posts SET review_status = ?, title_override = ?, project_override = ?,
                   category_override = ?, note = ? WHERE id = ?""",
                (status, title.strip(), project.strip(), category.strip(), note.strip(), post_id),
            )

    def list_matched_posts(self, limit: int = 100, include_excluded: bool = False):
        excluded = "" if include_excluded else "AND p.review_status <> 'excluded'"
        with self.connect() as conn:
            return conn.execute(
                f"""SELECT
                    p.*, c.name AS community_name, c.source AS community_source,
                    c.kind AS community_kind,
                    GROUP_CONCAT(DISTINCT q.label) AS matched_labels,
                    GROUP_CONCAT(DISTINCT NULLIF(q.project, '')) AS matched_projects,
                    GROUP_CONCAT(DISTINCT NULLIF(q.category, '')) AS matched_categories,
                    COUNT(m.query_id) AS match_count
                FROM posts p
                JOIN communities c ON c.id = p.community_id
                JOIN matches m ON m.post_id = p.id
                JOIN queries q ON q.id = m.query_id
                WHERE 1 = 1 {excluded}
                GROUP BY p.id
                ORDER BY p.published_ts DESC
                LIMIT ?""",
                (limit,),
            ).fetchall()

    def list_unnotified_matched_posts(self, peer_id: int, limit: int = 50):
        """Return matched posts that have not yet been delivered to this peer."""
        with self.connect() as conn:
            return conn.execute(
                """SELECT
                    p.*, c.name AS community_name, c.source AS community_source,
                    c.kind AS community_kind,
                    GROUP_CONCAT(DISTINCT q.label) AS matched_labels,
                    GROUP_CONCAT(DISTINCT NULLIF(q.project, '')) AS matched_projects,
                    GROUP_CONCAT(DISTINCT NULLIF(q.category, '')) AS matched_categories,
                    COUNT(m.query_id) AS match_count
                FROM posts p
                JOIN communities c ON c.id = p.community_id
                JOIN matches m ON m.post_id = p.id
                JOIN queries q ON q.id = m.query_id
                LEFT JOIN notifications n
                  ON n.post_id = p.id AND n.peer_id = ?
                WHERE p.review_status <> 'excluded' AND n.post_id IS NULL
                GROUP BY p.id
                ORDER BY p.published_ts DESC
                LIMIT ?""",
                (int(peer_id), int(limit)),
            ).fetchall()

    def count_unnotified_matched_posts(self, peer_id: int) -> int:
        with self.connect() as conn:
            row = conn.execute(
                """SELECT COUNT(DISTINCT p.id) AS total
                FROM posts p
                JOIN matches m ON m.post_id = p.id
                WHERE p.review_status <> 'excluded'
                  AND NOT EXISTS (
                      SELECT 1 FROM notifications n
                      WHERE n.post_id = p.id AND n.peer_id = ?
                  )""",
                (int(peer_id),),
            ).fetchone()
            return int(row["total"])

    def has_notification_run(self, peer_id: int, report_date: str) -> bool:
        with self.connect() as conn:
            row = conn.execute(
                """SELECT 1 FROM notification_runs
                   WHERE peer_id = ? AND report_date = ?""",
                (int(peer_id), report_date),
            ).fetchone()
            return row is not None

    def record_notification_delivery(
        self,
        peer_id: int,
        report_date: str,
        post_ids: list[int] | tuple[int, ...],
    ) -> None:
        """Record a successful VK delivery without exposing message contents."""
        sent_at = utc_now_iso()
        ids = [int(post_id) for post_id in post_ids]
        with self.connect() as conn:
            if ids:
                conn.executemany(
                    """INSERT OR IGNORE INTO notifications(post_id, peer_id, sent_at)
                       VALUES (?, ?, ?)""",
                    [(post_id, int(peer_id), sent_at) for post_id in ids],
                )
            conn.execute(
                """INSERT INTO notification_runs(peer_id, report_date, sent_at, posts_sent)
                   VALUES (?, ?, ?, ?)
                   ON CONFLICT(peer_id, report_date) DO UPDATE SET
                       sent_at = excluded.sent_at,
                       posts_sent = notification_runs.posts_sent + excluded.posts_sent""",
                (int(peer_id), report_date, sent_at, len(ids)),
            )

    def dashboard_stats(self) -> dict:
        with self.connect() as conn:
            row = conn.execute(
                """SELECT
                    (SELECT COUNT(*) FROM communities WHERE enabled = 1) AS communities,
                    (SELECT COUNT(*) FROM queries WHERE enabled = 1) AS queries,
                    (SELECT COUNT(*) FROM posts) AS posts,
                    (SELECT COUNT(DISTINCT post_id) FROM matches) AS matched_posts,
                    (SELECT COUNT(DISTINCT post_id) FROM matches m JOIN posts p ON p.id=m.post_id
                        WHERE p.review_status='new') AS awaiting_review,
                    (SELECT MAX(finished_at) FROM scans WHERE status IN ('ok','partial')) AS last_scan
                """
            ).fetchone()
            return dict(row)

    def monthly_media_stats(self, since_ts: int, until_ts: int) -> dict:
        with self.connect() as conn:
            row = conn.execute(
                """SELECT
                    COUNT(DISTINCT CASE WHEN c.kind = 'own' THEN p.id END) AS posts_total,
                    COUNT(DISTINCT CASE WHEN c.kind = 'own' AND p.is_repost = 0 THEN p.id END) AS original_posts,
                    COUNT(DISTINCT CASE
                        WHEN c.kind IN ('city','media')
                         AND EXISTS (SELECT 1 FROM matches m WHERE m.post_id = p.id)
                        THEN p.id END) AS city_media_posts
                FROM posts p
                JOIN communities c ON c.id = p.community_id
                WHERE p.published_ts >= ? AND p.published_ts < ?
                  AND p.review_status <> 'excluded'""",
                (since_ts, until_ts),
            ).fetchone()
            return dict(row)

    def list_scans(self, limit: int = 30):
        with self.connect() as conn:
            return conn.execute(
                "SELECT * FROM scans ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
