from __future__ import annotations

from datetime import datetime
import base64
import hashlib
import hmac
import html
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse
from zoneinfo import ZoneInfo

from .reports import export_report_csv


KIND_LABELS = {
    "own": "Основное сообщество",
    "primary": "Первичная организация",
    "city": "Городское сообщество",
    "media": "СМИ",
    "other": "Другое",
    "hashtag": "Хештег",
    "phrase": "Фраза",
    "mention": "Упоминание страницы",
    "words_any": "Любое из слов",
    "words_all": "Все слова",
}


def esc(value) -> str:
    return html.escape(str(value if value is not None else ""), quote=True)


def checked(value) -> str:
    return "checked" if value else ""


def layout(title: str, body: str, token_configured: bool) -> str:
    token_badge = (
        '<span class="badge ok">VK подключён</span>'
        if token_configured
        else '<span class="badge warn">Нужен токен VK</span>'
    )
    return f"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)} — Мониторинг VK</title>
<style>
:root{{--blue:#3366CC;--red:#D90912;--ink:#101828;--muted:#667085;--line:#E4E7EC;--bg:#F7F8FC;}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 Arial,sans-serif}}
header{{background:linear-gradient(125deg,var(--blue),#2048A2);color:#fff;padding:20px 0;border-bottom:5px solid var(--red)}}
.wrap{{max-width:1220px;margin:auto;padding:0 22px}} h1{{font-size:25px;margin:0 0 5px}} h2{{font-size:20px;margin:0 0 16px}} h3{{margin:0 0 10px}}
nav{{display:flex;gap:8px;flex-wrap:wrap;margin-top:15px}} nav a{{color:#fff;text-decoration:none;padding:7px 11px;border-radius:8px;background:#ffffff1c}}
nav a:hover{{background:#ffffff33}} main{{padding:24px 22px 50px}} .topline{{display:flex;justify-content:space-between;gap:20px;align-items:start}}
.badge{{display:inline-block;padding:5px 9px;border-radius:999px;font-size:13px;font-weight:700}} .ok{{background:#E7F8EF;color:#067647}} .warn{{background:#FFF1F0;color:#B42318}}
.muted{{color:var(--muted)}} .grid{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:16px 0 22px}} .card{{background:#fff;border:1px solid var(--line);border-radius:14px;padding:17px;box-shadow:0 4px 15px #1018280a}}
.metric{{font-size:29px;font-weight:800;color:var(--blue)}} .metric.red{{color:var(--red)}} .section{{background:#fff;border:1px solid var(--line);border-radius:14px;padding:20px;margin:0 0 18px;overflow:auto}}
table{{border-collapse:collapse;width:100%;min-width:720px}} th,td{{text-align:left;padding:10px;border-bottom:1px solid var(--line);vertical-align:top}} th{{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);background:#F9FAFB}} tr:last-child td{{border-bottom:0}}
input,select,textarea{{width:100%;border:1px solid #D0D5DD;border-radius:8px;padding:9px;background:#fff;font:inherit}} textarea{{min-height:76px;resize:vertical}} label{{display:block;font-weight:700;font-size:13px;margin-bottom:5px}}
.formgrid{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}} .wide{{grid-column:1/-1}} button,.button{{border:0;border-radius:8px;padding:9px 14px;background:var(--blue);color:#fff;font-weight:700;cursor:pointer;text-decoration:none;display:inline-block}} button.secondary{{background:#667085}} button.red{{background:var(--red)}}
.inline{{display:inline}} .inline button{{padding:6px 9px;font-size:12px}} .flash{{padding:11px 14px;border-radius:10px;background:#EAF0FF;color:#173E95;margin-bottom:16px}} .error{{color:#B42318;white-space:pre-wrap;max-width:430px}}
.posttext{{max-width:540px;white-space:pre-wrap;max-height:170px;overflow:auto}} details summary{{cursor:pointer;color:var(--blue);font-weight:700}} .review{{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}} .review .wide{{grid-column:1/-1}}
.progress{{height:9px;background:#EAECF0;border-radius:9px;overflow:hidden;margin-top:8px}} .progress i{{display:block;height:100%;background:var(--blue)}}
@media(max-width:850px){{.grid{{grid-template-columns:repeat(2,1fr)}}.formgrid,.review{{grid-template-columns:1fr}}.topline{{display:block}}}}
</style></head><body>
<header><div class="wrap"><div class="topline"><div><h1>Мониторинг публикаций ВКонтакте</h1><div>Движение Первых · Кемский муниципальный округ</div></div><div>{token_badge}</div></div>
<nav><a href="/">Обзор</a><a href="/communities">Сообщества</a><a href="/queries">Поисковые запросы</a><a href="/posts">Найденные посты</a><a href="/scans">История проверок</a><a href="/export.csv">Скачать отчёт CSV</a></nav></div></header>
<main class="wrap">{body}</main></body></html>"""


def make_handler(database, settings, scan_controller, scheduler=None):
    class Handler(BaseHTTPRequestHandler):
        server_version = "VKMonitorPervye/0.1"

        def log_message(self, format, *args):
            # Keep access logs concise and never include request bodies or secrets.
            super().log_message(format, *args)

        def _authorized(self) -> bool:
            if not settings.web_password:
                return True
            header = self.headers.get("Authorization", "")
            if not header.startswith("Basic "):
                return False
            try:
                decoded = base64.b64decode(header[6:], validate=True).decode("utf-8")
                username, password = decoded.split(":", 1)
            except Exception:
                return False
            user_ok = hmac.compare_digest(username, "admin")
            pass_ok = hmac.compare_digest(password, settings.web_password)
            return user_ok and pass_ok

        def _require_auth(self) -> bool:
            if self._authorized():
                return True
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="VK Monitor"')
            self.send_header("Content-Length", "0")
            self.end_headers()
            return False

        def _send(self, body: str | bytes, status=200, content_type="text/html; charset=utf-8"):
            data = body.encode("utf-8") if isinstance(body, str) else body
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            self.wfile.write(data)

        def _redirect(self, path: str, message: str = ""):
            suffix = ("?message=" + quote(message)) if message else ""
            self.send_response(303)
            self.send_header("Location", path + suffix)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def _form(self):
            length = min(int(self.headers.get("Content-Length", "0")), 200_000)
            raw = self.rfile.read(length).decode("utf-8", errors="replace")
            return {key: values[0] for key, values in parse_qs(raw).items()}

        def _message(self, parsed) -> str:
            values = parse_qs(parsed.query).get("message", [])
            return f'<div class="flash">{esc(values[0])}</div>' if values else ""

        def do_GET(self):
            parsed = urlparse(self.path)
            if parsed.path == "/health":
                return self._send("ok", content_type="text/plain; charset=utf-8")
            if not self._require_auth():
                return
            try:
                if parsed.path == "/":
                    return self._dashboard(parsed)
                if parsed.path == "/communities":
                    return self._communities(parsed)
                if parsed.path == "/queries":
                    return self._queries(parsed)
                if parsed.path == "/posts":
                    return self._posts(parsed)
                if parsed.path == "/scans":
                    return self._scans(parsed)
                if parsed.path == "/export.csv":
                    data = export_report_csv(database, settings.timezone)
                    self.send_response(200)
                    self.send_header("Content-Type", "text/csv; charset=utf-8")
                    self.send_header("Content-Disposition", 'attachment; filename="vk_report.csv"')
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                return self._send("Страница не найдена", 404, "text/plain; charset=utf-8")
            except Exception as exc:
                body = layout("Ошибка", f'<div class="section"><h2>Ошибка</h2><div class="error">{esc(exc)}</div></div>', settings.token_configured)
                return self._send(body, 500)

        def do_POST(self):
            if not self._require_auth():
                return
            parsed = urlparse(self.path)
            form = self._form()
            try:
                if parsed.path == "/scan":
                    if not settings.token_configured:
                        return self._redirect("/", "Сначала добавьте VK_ACCESS_TOKEN в файл .env")
                    started = scan_controller.start()
                    return self._redirect("/", "Проверка запущена" if started else "Проверка уже выполняется")
                if parsed.path == "/communities/add":
                    raw_sources = form.get("sources", form.get("source", ""))
                    lines = [line.strip() for line in raw_sources.splitlines() if line.strip()]
                    if not lines:
                        raise ValueError("Добавьте хотя бы одно сообщество")
                    added = 0
                    for line in lines:
                        source, separator, inline_name = line.partition(";")
                        default_name = form.get("name", "") if len(lines) == 1 else ""
                        added += int(database.add_community(
                            source.strip(), inline_name.strip() if separator else default_name,
                            form.get("kind", "other"),
                        ))
                    return self._redirect("/communities", f"Добавлено сообществ: {added}; пропущено повторов: {len(lines) - added}")
                if parsed.path == "/communities/toggle":
                    database.toggle_community(int(form["id"]))
                    return self._redirect("/communities", "Статус сообщества изменён")
                if parsed.path == "/queries/add":
                    created = database.add_query(
                        form.get("kind", "phrase"), form.get("pattern", ""),
                        form.get("label", ""), form.get("project", ""), form.get("category", ""),
                    )
                    return self._redirect("/queries", "Запрос добавлен" if created else "Такой запрос уже есть")
                if parsed.path == "/queries/toggle":
                    database.toggle_query(int(form["id"]))
                    return self._redirect("/queries", "Статус запроса изменён")
                if parsed.path == "/review":
                    database.review_post(
                        int(form["id"]), form.get("status", "new"), form.get("title", ""),
                        form.get("project", ""), form.get("category", ""), form.get("note", ""),
                    )
                    return self._redirect("/posts", "Решение сохранено")
                return self._send("Страница не найдена", 404, "text/plain; charset=utf-8")
            except Exception as exc:
                target = "/" if parsed.path == "/scan" else "/" + parsed.path.strip("/").split("/", 1)[0]
                return self._redirect(target, f"Ошибка: {exc}")

        def _dashboard(self, parsed):
            stats = database.dashboard_stats()
            tz = ZoneInfo(settings.timezone)
            now = datetime.now(tz)
            month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            if month_start.month == 12:
                next_month = month_start.replace(year=month_start.year + 1, month=1)
            else:
                next_month = month_start.replace(month=month_start.month + 1)
            media = database.monthly_media_stats(int(month_start.timestamp()), int(next_month.timestamp()))
            total_pct = min(100, round(media["posts_total"] / 26 * 100)) if media["posts_total"] else 0
            original_pct = min(100, round(media["original_posts"] / 13 * 100)) if media["original_posts"] else 0
            city_pct = min(100, round(media["city_media_posts"] / 3 * 100)) if media["city_media_posts"] else 0
            next_run = scheduler.next_run().strftime("%d.%m.%Y %H:%M") if scheduler else "планировщик выключен"
            state = "выполняется" if scan_controller.running else "ожидает"
            error = f'<div class="flash error">Последняя ошибка: {esc(scan_controller.last_error)}</div>' if scan_controller.last_error else ""
            rows = database.list_matched_posts(limit=12)
            recent = "".join(
                f"<tr><td>{datetime.fromtimestamp(r['published_ts'], tz).strftime('%d.%m.%Y')}</td>"
                f"<td>{esc(r['community_name'] or r['community_source'])}</td>"
                f"<td>{esc(r['matched_labels'] or '')}</td>"
                f"<td><a href=\"{esc(r['source_url'])}\" target=\"_blank\" rel=\"noreferrer\">Открыть</a></td></tr>"
                for r in rows
            ) or '<tr><td colspan="4" class="muted">Совпадений пока нет. Добавьте сообщества и запустите проверку.</td></tr>'
            body = self._message(parsed) + error + f"""
<div class="topline"><div><h2>Обзор</h2><div class="muted">Следующая автоматическая проверка: {esc(next_run)} · состояние: {state}</div></div>
<form action="/scan" method="post"><button class="red">Проверить сейчас</button></form></div>
<div class="grid"><div class="card"><div class="muted">Сообществ включено</div><div class="metric">{stats['communities']}</div></div>
<div class="card"><div class="muted">Поисковых правил</div><div class="metric">{stats['queries']}</div></div>
<div class="card"><div class="muted">Найдено постов</div><div class="metric">{stats['matched_posts']}</div></div>
<div class="card"><div class="muted">Ждут проверки</div><div class="metric red">{stats['awaiting_review']}</div></div></div>
<div class="section"><h2>Медиа за {now.strftime('%m.%Y')}</h2>
<div class="grid"><div><b>Посты основного сообщества</b><div>{media['posts_total']} из 26</div><div class="progress"><i style="width:{total_pct}%"></i></div></div>
<div><b>Оригинальные посты</b><div>{media['original_posts']} из 13</div><div class="progress"><i style="width:{original_pct}%"></i></div></div>
<div><b>Городские сообщества / СМИ</b><div>{media['city_media_posts']} из 3</div><div class="progress"><i style="width:{city_pct}%"></i></div></div></div>
<div class="muted">Баллы за качество и предоставление материалов требуют ручного подтверждения.</div></div>
<div class="section"><h2>Последние совпадения</h2><table><thead><tr><th>Дата</th><th>Сообщество</th><th>Найдено</th><th>Пост</th></tr></thead><tbody>{recent}</tbody></table></div>"""
            return self._send(layout("Обзор", body, settings.token_configured))

        def _communities(self, parsed):
            rows = database.list_communities()
            items = "".join(
                f"<tr><td>{esc(r['name'] or '—')}</td><td>{esc(r['source'])}</td><td>{esc(KIND_LABELS.get(r['kind'], r['kind']))}</td>"
                f"<td>{'включено' if r['enabled'] else 'выключено'}</td><td>{esc(r['last_scan_at'] or '—')}</td>"
                f"<td class=\"error\">{esc(r['last_error'])}</td><td><form class=\"inline\" method=\"post\" action=\"/communities/toggle\"><input type=\"hidden\" name=\"id\" value=\"{r['id']}\"><button class=\"secondary\">{'Выключить' if r['enabled'] else 'Включить'}</button></form></td></tr>"
                for r in rows
            ) or '<tr><td colspan="7" class="muted">Список пуст.</td></tr>'
            body = self._message(parsed) + f"""<div class="section"><h2>Добавить сообщество</h2>
<form action="/communities/add" method="post" class="formgrid"><div class="wide"><label>Ссылки, короткие имена или ID — по одному в строке</label><textarea name="sources" required placeholder="https://vk.ru/club123456\nhttps://vk.ru/school_example; Школа № 1"></textarea><div class="muted">Название можно указать после точки с запятой. Для списка применяется один тип.</div></div>
<div><label>Название, если добавляется одна строка</label><input name="name" placeholder="Основное сообщество"></div><div><label>Тип</label><select name="kind"><option value="own">Основное сообщество</option><option value="primary">Первичная организация</option><option value="city">Городское сообщество</option><option value="media">СМИ</option><option value="other">Другое</option></select></div>
<div class="wide"><button>Добавить</button></div></form></div>
<div class="section"><h2>Контролируемые сообщества</h2><table><thead><tr><th>Название</th><th>Источник</th><th>Тип</th><th>Статус</th><th>Последняя проверка</th><th>Ошибка</th><th></th></tr></thead><tbody>{items}</tbody></table></div>"""
            return self._send(layout("Сообщества", body, settings.token_configured))

        def _queries(self, parsed):
            rows = database.list_queries()
            items = "".join(
                f"<tr><td>{esc(KIND_LABELS.get(r['kind'], r['kind']))}</td><td>{esc(r['pattern'])}</td><td>{esc(r['label'])}</td><td>{esc(r['project'])}</td><td>{esc(r['category'])}</td><td>{'включено' if r['enabled'] else 'выключено'}</td>"
                f"<td><form class=\"inline\" method=\"post\" action=\"/queries/toggle\"><input type=\"hidden\" name=\"id\" value=\"{r['id']}\"><button class=\"secondary\">{'Выключить' if r['enabled'] else 'Включить'}</button></form></td></tr>"
                for r in rows
            )
            body = self._message(parsed) + f"""<div class="section"><h2>Добавить поисковое правило</h2>
<form action="/queries/add" method="post" class="formgrid"><div><label>Тип поиска</label><select name="kind"><option value="hashtag">Точный хештег</option><option value="phrase">Фраза в тексте</option><option value="mention">Упоминание страницы VK</option><option value="words_all">Все перечисленные фразы</option><option value="words_any">Любая из перечисленных фраз</option></select></div>
<div><label>Что искать</label><input name="pattern" required placeholder="#ПервыеКемь или Зарница 2.0"></div><div><label>Название правила</label><input name="label" placeholder="Заполнится автоматически"></div>
<div><label>Проект 2026</label><input name="project"></div><div><label>Категория отчётности</label><input name="category"></div><div style="align-self:end"><button>Добавить правило</button></div></form></div>
<div class="section"><h2>Поисковые правила</h2><table><thead><tr><th>Тип</th><th>Запрос</th><th>Метка</th><th>Проект</th><th>Категория</th><th>Статус</th><th></th></tr></thead><tbody>{items}</tbody></table></div>"""
            return self._send(layout("Поисковые запросы", body, settings.token_configured))

        def _posts(self, parsed):
            tz = ZoneInfo(settings.timezone)
            rows = database.list_matched_posts(limit=300)
            items = []
            for r in rows:
                status_options = "".join(
                    f'<option value="{value}" {"selected" if r["review_status"] == value else ""}>{label}</option>'
                    for value, label in (("new", "Новый"), ("reviewed", "Подтверждён"), ("excluded", "Исключён"))
                )
                text = str(r["text"] or "")
                if r["repost_text"]:
                    text += "\n\nРепост:\n" + str(r["repost_text"])
                items.append(f"""<tr><td>{datetime.fromtimestamp(r['published_ts'], tz).strftime('%d.%m.%Y %H:%M')}</td>
<td>{esc(r['community_name'] or r['community_source'])}<br><span class="muted">{esc(KIND_LABELS.get(r['community_kind'], r['community_kind']))}</span></td>
<td><div class="posttext">{esc(text)}</div><p><a href="{esc(r['source_url'])}" target="_blank" rel="noreferrer">Открыть публикацию</a></p></td>
<td>{esc(r['matched_labels'] or '')}<br><span class="muted">{r['views']} просмотров · {r['likes']} лайков</span></td>
<td><details><summary>Проверить</summary><form action="/review" method="post" class="review"><input type="hidden" name="id" value="{r['id']}">
<div><label>Статус</label><select name="status">{status_options}</select></div><div><label>Название мероприятия</label><input name="title" value="{esc(r['title_override'])}"></div>
<div><label>Проект</label><input name="project" value="{esc(r['project_override'] or r['matched_projects'] or '')}"></div><div><label>Категория</label><input name="category" value="{esc(r['category_override'] or r['matched_categories'] or '')}"></div>
<div class="wide"><label>Примечание</label><textarea name="note">{esc(r['note'])}</textarea></div><div class="wide"><button>Сохранить</button></div></form></details></td></tr>""")
            table_rows = "".join(items) or '<tr><td colspan="5" class="muted">Совпадений пока нет.</td></tr>'
            body = self._message(parsed) + f"""<div class="topline"><div><h2>Найденные публикации</h2><div class="muted">Перед включением в официальный отчёт подтвердите категорию и название мероприятия.</div></div><a class="button" href="/export.csv">Скачать CSV</a></div>
<div class="section"><table><thead><tr><th>Дата</th><th>Сообщество</th><th>Текст</th><th>Совпадения</th><th>Решение</th></tr></thead><tbody>{table_rows}</tbody></table></div>"""
            return self._send(layout("Найденные посты", body, settings.token_configured))

        def _scans(self, parsed):
            rows = database.list_scans()
            items = "".join(
                f"<tr><td>{esc(r['started_at'])}</td><td>{esc(r['status'])}</td><td>{r['communities_ok']} / {r['communities_total']}</td><td>{r['posts_seen']}</td><td>{r['matches_found']}</td><td class=\"error\">{esc(r['error'])}</td></tr>"
                for r in rows
            ) or '<tr><td colspan="6" class="muted">Проверки ещё не запускались.</td></tr>'
            body = self._message(parsed) + f"""<div class="section"><h2>История проверок</h2><table><thead><tr><th>Начало</th><th>Статус</th><th>Сообщества</th><th>Постов проверено</th><th>Совпадений</th><th>Ошибки</th></tr></thead><tbody>{items}</tbody></table></div>"""
            return self._send(layout("История проверок", body, settings.token_configured))

    return Handler


def serve(database, settings, scan_controller, scheduler=None):
    handler = make_handler(database, settings, scan_controller, scheduler)
    server = ThreadingHTTPServer((settings.host, settings.port), handler)
    print(f"Панель открыта: http://{settings.host}:{settings.port}")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
