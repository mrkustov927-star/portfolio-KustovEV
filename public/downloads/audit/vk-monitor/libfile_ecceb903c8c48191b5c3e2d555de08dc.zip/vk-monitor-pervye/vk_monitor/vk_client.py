from __future__ import annotations

from dataclasses import dataclass
import json
import socket
import ssl
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen


class VKAPIError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class ResolvedGroup:
    id: int
    name: str
    screen_name: str


def _counter(item: dict, name: str) -> int:
    value = item.get(name, {})
    return int(value.get("count", 0)) if isinstance(value, dict) else 0


def _copy_history_text(items: list[dict] | None) -> str:
    parts: list[str] = []
    for item in items or []:
        text = str(item.get("text") or "").strip()
        if text:
            parts.append(text)
        nested = _copy_history_text(item.get("copy_history"))
        if nested:
            parts.append(nested)
    return "\n\n".join(parts)


def normalize_group_source(source: str) -> str:
    value = source.strip()
    if not value:
        raise ValueError("Пустой адрес сообщества")
    if "://" in value:
        parsed = urlparse(value)
        value = parsed.path.strip("/").split("/", 1)[0]
    else:
        for prefix in ("vk.ru/", "vk.com/", "m.vk.com/"):
            if value.lower().startswith(prefix):
                value = value[len(prefix):]
                break
        value = value.strip("/").split("?", 1)[0]
    if value.startswith("-") and value[1:].isdigit():
        return value[1:]
    if value.startswith("club") and value[4:].isdigit():
        return value[4:]
    if value.startswith("public") and value[6:].isdigit():
        return value[6:]
    return value


class VKClient:
    endpoint = "https://api.vk.com/method"

    def __init__(
        self,
        access_token: str,
        api_version: str = "5.199",
        link_domain: str = "vk.ru",
        timeout: int = 30,
    ):
        if not access_token.strip():
            raise ValueError("VK_ACCESS_TOKEN не задан")
        self.access_token = access_token.strip()
        self.api_version = api_version
        self.link_domain = link_domain
        self.timeout = timeout
        self._ssl_context = ssl.create_default_context()
        self._last_request_at = 0.0

    def _throttle(self) -> None:
        elapsed = time.monotonic() - self._last_request_at
        if elapsed < 0.36:
            time.sleep(0.36 - elapsed)

    def call(self, method: str, **params):
        payload = {**params, "access_token": self.access_token, "v": self.api_version}
        last_exception = None
        for attempt in range(3):
            self._throttle()
            request = Request(
                f"{self.endpoint}/{method}",
                data=urlencode(payload).encode("utf-8"),
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "User-Agent": "vk-monitor-pervye/0.2",
                },
                method="POST",
            )
            try:
                with urlopen(request, timeout=self.timeout, context=self._ssl_context) as response:
                    self._last_request_at = time.monotonic()
                    body = json.loads(response.read().decode("utf-8"))
            except HTTPError as exc:
                self._last_request_at = time.monotonic()
                last_exception = VKAPIError(f"VK API вернул HTTP {exc.code}")
                if attempt < 2 and (exc.code == 429 or 500 <= exc.code < 600):
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise last_exception from exc
            except (URLError, socket.timeout, json.JSONDecodeError) as exc:
                self._last_request_at = time.monotonic()
                last_exception = VKAPIError(f"Не удалось связаться с VK API: {type(exc).__name__}")
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise last_exception from exc
            if "error" in body:
                error = body["error"]
                code = error.get("error_code", "?")
                message = error.get("error_msg", "Неизвестная ошибка")
                last_exception = VKAPIError(f"VK API {code}: {message}")
                if attempt < 2 and code in {6, 9, 10}:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise last_exception
            if "response" not in body:
                raise VKAPIError("VK API вернул ответ неизвестного формата")
            return body["response"]
        raise last_exception or VKAPIError("Не удалось выполнить запрос к VK API")

    def resolve_group(self, source: str) -> dict:
        group_ref = normalize_group_source(source)
        response = self.call("groups.getById", group_ids=group_ref)
        if isinstance(response, dict):
            items = response.get("groups") or response.get("items") or []
        else:
            items = response
        if not items:
            raise VKAPIError(f"Сообщество не найдено: {source}")
        item = items[0]
        return {
            "id": int(item["id"]),
            "name": str(item.get("name") or group_ref),
            "screen_name": str(item.get("screen_name") or group_ref),
        }

    def iter_wall_posts(self, group_id: int, since_ts: int, max_pages: int = 30):
        owner_id = -abs(int(group_id))
        seen: set[tuple[int, int]] = set()
        for page in range(max_pages):
            response = self.call(
                "wall.get",
                owner_id=owner_id,
                count=100,
                offset=page * 100,
                filter="owner",
            )
            items = response.get("items", []) if isinstance(response, dict) else []
            if not items:
                break
            reached_old_posts = True
            for item in items:
                post_id = int(item.get("id", 0))
                post_owner_id = int(item.get("owner_id", owner_id))
                published_ts = int(item.get("date", 0))
                is_pinned = bool(item.get("is_pinned"))
                if published_ts >= since_ts:
                    reached_old_posts = False
                if published_ts < since_ts and not is_pinned:
                    continue
                key = (post_owner_id, post_id)
                if not post_id or key in seen:
                    continue
                seen.add(key)
                copy_history = item.get("copy_history") or []
                yield {
                    "id": post_id,
                    "owner_id": post_owner_id,
                    "date": published_ts,
                    "text": str(item.get("text") or ""),
                    "repost_text": _copy_history_text(copy_history),
                    "is_repost": bool(copy_history),
                    "source_url": f"https://{self.link_domain}/wall{post_owner_id}_{post_id}",
                    "likes": _counter(item, "likes"),
                    "comments": _counter(item, "comments"),
                    "reposts": _counter(item, "reposts"),
                    "views": _counter(item, "views"),
                    "raw": {
                        "post_type": item.get("post_type"),
                        "marked_as_ads": item.get("marked_as_ads", 0),
                        "is_pinned": item.get("is_pinned", 0),
                        "attachments": [
                            attachment.get("type")
                            for attachment in item.get("attachments", [])
                            if isinstance(attachment, dict)
                        ],
                    },
                }
            if len(items) < 100 or reached_old_posts:
                break

    def test_connection(self) -> dict:
        # Public, stable test object; no personal data is requested.
        return self.resolve_group("1")
