from __future__ import annotations

import re


DEFAULT_QUERIES = [
    # Основные хештеги Кемского муниципального округа.
    ("hashtag", "#ДвижениеПервых10", "Движение Первых", "", "Медиа"),
    ("hashtag", "#ПервыеКемь", "Первые Кемь", "", "Медиа"),
    ("hashtag", "#ПервыеПомнят", "Первые помнят", "", "Медиа"),
    ("hashtag", "#КемскийОкруг", "Кемский округ", "", "Медиа"),
    ("phrase", "Движение Первых", "Упоминание Движения Первых", "", "Медиа"),
    ("phrase", "Совет Первых", "Совет Первых", "", "Организационная, методическая и воспитательная деятельность"),
    ("phrase", "Родные-Любимые", "Родные-Любимые", "Родные-Любимые", "Системная деятельность в рамках направлений деятельности Движения Первых"),
]


PROJECTS_2026 = [
    "Первая помощь",
    "Вызов Первых",
    "Гуру Физкультуры",
    "Семейная команда",
    "Походы Первых",
    "Юннаты Первых",
    "Школьная классика",
    "Благо твори",
    "Обучение служением. Первые",
    "Первые в профессии",
    "Первая работа",
    "Зарница 2.0",
    "Семейная зарница",
    "Первые в науке",
    "Волонтеры Науки",
    "МедиаПритяжение",
    "МедиаПрофориентация",
    "Медиазачет",
    "Значимый взрослый",
    "Ёлка желаний",
    "Российский детский Дед Мороз",
    "Пилоты будущего",
    "Фестиваль Движения Первых",
    "Большая перемена",
    "Премия Первых",
    "Школа актива Первых",
    "Профессиональная команда Первых",
    "Флагманы возможностей",
    "Конкурс первичных отделений Движения Первых",
    "Приключения Первых",
    "Первый танцевальный",
    "Старт года",
    "Маршруты Первых",
    "Первые Первым",
    "Miäččy",
    "Кибернетика Первых",
    "Первый студенческий",
    "КВН.Первые",
    "Хор Первых",
    "Кастинги Первых",
    "Российская школьная весна",
    "Мы - граждане России",
    "Хранители истории",
    "Достижения Первых",
]


def seed_defaults(database) -> tuple[int, int]:
    inserted = 0
    for kind, pattern, label, project, category in DEFAULT_QUERIES:
        inserted += int(database.add_query(kind, pattern, label, project, category))
    for project in PROJECTS_2026:
        inserted += int(database.add_query("phrase", project, project, project, ""))
    return inserted, len(DEFAULT_QUERIES) + len(PROJECTS_2026)


def seed_communities(database, raw: str) -> tuple[int, int]:
    """Seed `source|name|kind` records separated by commas or new lines."""
    records = [record.strip() for record in re.split(r"[,\n]+", raw or "") if record.strip()]
    inserted = 0
    for record in records:
        parts = [part.strip() for part in record.split("|", 2)]
        source = parts[0]
        name = parts[1] if len(parts) > 1 else ""
        kind = parts[2] if len(parts) > 2 and parts[2] else "other"
        inserted += int(database.add_community(source, name, kind))
    return inserted, len(records)
