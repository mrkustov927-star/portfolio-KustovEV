from __future__ import annotations

from datetime import datetime, timedelta
import threading
from zoneinfo import ZoneInfo


class ScanController:
    def __init__(self, scanner_factory, after_scan=None):
        self.scanner_factory = scanner_factory
        self.after_scan = after_scan
        self._lock = threading.Lock()
        self.running = False
        self.last_result = None
        self.last_error = ""
        self.last_started_at = None

    def _run(self):
        with self._lock:
            if self.running:
                return
            self.running = True
        try:
            self.last_started_at = datetime.now().astimezone().isoformat(timespec="seconds")
            self.last_result = self.scanner_factory().run().to_dict()
            if self.after_scan:
                self.after_scan(self.last_result)
            self.last_error = ""
        except Exception as exc:
            self.last_error = str(exc)
        finally:
            with self._lock:
                self.running = False

    def start(self) -> bool:
        with self._lock:
            if self.running:
                return False
        thread = threading.Thread(target=self._run, name="vk-scan", daemon=True)
        thread.start()
        return True

    def run_sync(self):
        self._run()
        if self.last_error:
            raise RuntimeError(self.last_error)
        return self.last_result


class DailyScheduler:
    def __init__(self, controller: ScanController, scan_time: str, timezone_name: str):
        self.controller = controller
        self.hour, self.minute = (int(value) for value in scan_time.split(":"))
        self.timezone = ZoneInfo(timezone_name)
        self.stop_event = threading.Event()
        self.thread = None

    def next_run(self, now: datetime | None = None) -> datetime:
        now = now or datetime.now(self.timezone)
        candidate = now.replace(hour=self.hour, minute=self.minute, second=0, microsecond=0)
        if candidate <= now:
            candidate += timedelta(days=1)
        return candidate

    def _loop(self):
        while not self.stop_event.is_set():
            now = datetime.now(self.timezone)
            wait_seconds = max(1.0, (self.next_run(now) - now).total_seconds())
            if self.stop_event.wait(wait_seconds):
                return
            self.controller.start()

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._loop, name="vk-daily-scheduler", daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=5)
