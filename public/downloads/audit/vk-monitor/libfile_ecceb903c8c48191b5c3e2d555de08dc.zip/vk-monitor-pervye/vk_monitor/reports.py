from __future__ import annotations

from datetime import datetime
import csv
import io
from zoneinfo import ZoneInfo


REPORT_HEADERS = [
    "Сроки проведения",
    "Название мероприятия",
    "Описание мероприятия",
    "Категория мероприятия",
    "Ссылка на посты по мероприятию",
    "Примечание",
    "Проект 2026",
    "Сообщество",
    "Тип сообщества",
    "Найденные запросы",
    "Оригинальный пост",
    "Просмотры",
    "Лайки",
    "Репосты",
    "Комментарии",
    "Статус проверки",
]


def _short_title(row) -> str:
    if row["title_override"]:
        return row["title_override"]
    if row["matched_projects"]:
        return str(row["matched_projects"]).split(",", 1)[0]
    if row["matched_labels"]:
        return str(row["matched_labels"]).split(",", 1)[0]
    text = " ".join(str(row["text"] or "").split())
    return (text[:77] + "...") if len(text) > 80 else text


def export_report_csv(database, timezone_name: str, limit: int = 10000) -> bytes:
    rows = database.list_matched_posts(limit=limit, include_excluded=False)
    timezone = ZoneInfo(timezone_name)
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, delimiter=";", quoting=csv.QUOTE_MINIMAL)
    writer.writerow(REPORT_HEADERS)
    for row in rows:
        published = datetime.fromtimestamp(row["published_ts"], timezone)
        project = row["project_override"] or row["matched_projects"] or ""
        category = row["category_override"] or row["matched_categories"] or ""
        metrics = (
            f"Совпадения: {row['matched_labels'] or '—'}. "
            f"Показатели на момент проверки: просмотры {row['views']}, "
            f"лайки {row['likes']}, репосты {row['reposts']}, комментарии {row['comments']}."
        )
        note = " ".join(part for part in (row["note"], metrics) if part)
        description = str(row["text"] or "")
        if row["repost_text"]:
            description += "\n\nТекст источника репоста:\n" + str(row["repost_text"])
        writer.writerow(
            [
                published.strftime("%d.%m.%Y"),
                _short_title(row),
                description,
                category,
                row["source_url"],
                note,
                project,
                row["community_name"] or row["community_source"],
                row["community_kind"],
                row["matched_labels"] or "",
                "Да" if not row["is_repost"] else "Нет",
                row["views"],
                row["likes"],
                row["reposts"],
                row["comments"],
                row["review_status"],
            ]
        )
    # UTF-8 BOM lets desktop Excel recognize Cyrillic without an import wizard.
    return ("\ufeff" + stream.getvalue()).encode("utf-8")

