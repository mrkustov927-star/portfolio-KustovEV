from __future__ import annotations

from dataclasses import dataclass, asdict
import time

from .matcher import match_text, searchable_post_text
from .vk_client import VKClient


@dataclass(slots=True)
class ScanSummary:
    scan_id: int
    communities_total: int = 0
    communities_ok: int = 0
    posts_seen: int = 0
    matched_posts: int = 0
    matches_found: int = 0
    errors: list[str] | None = None

    def to_dict(self):
        return asdict(self)


class Scanner:
    def __init__(self, database, settings, client: VKClient | None = None):
        self.database = database
        self.settings = settings
        self.client = client or VKClient(
            settings.access_token,
            settings.api_version,
            settings.link_domain,
        )

    def run(self) -> ScanSummary:
        communities = self.database.list_communities(enabled_only=True)
        queries = self.database.list_queries(enabled_only=True)
        scan_id = self.database.start_scan(len(communities))
        summary = ScanSummary(scan_id=scan_id, communities_total=len(communities), errors=[])
        scan_started_ts = int(time.time())

        try:
            for community in communities:
                try:
                    group = self.client.resolve_group(community["source"])
                    self.database.update_community_resolution(community["id"], group)
                    last_scan_ts = community["last_scan_ts"]
                    if last_scan_ts:
                        since_ts = max(
                            0,
                            int(last_scan_ts) - self.settings.lookback_days * 86400,
                        )
                    else:
                        since_ts = scan_started_ts - self.settings.initial_days * 86400

                    matched_this_community = 0
                    for post in self.client.iter_wall_posts(
                        group["id"],
                        since_ts,
                        self.settings.max_pages_per_community,
                    ):
                        summary.posts_seen += 1
                        post_db_id = self.database.upsert_post(community["id"], post)
                        search_text = searchable_post_text(post)
                        found = []
                        for query in queries:
                            result = match_text(query["kind"], query["pattern"], search_text)
                            if result.matched:
                                found.append(
                                    {
                                        "query_id": query["id"],
                                        "evidence": result.evidence,
                                        "confidence": result.confidence,
                                    }
                                )
                        self.database.replace_matches(post_db_id, found)
                        if found:
                            summary.matched_posts += 1
                            summary.matches_found += len(found)
                            matched_this_community += len(found)
                    self.database.update_community_scan(community["id"], scan_started_ts)
                    summary.communities_ok += 1
                except Exception as exc:  # isolate failure to one community
                    message = f"{community['source']}: {exc}"
                    summary.errors.append(message)
                    self.database.set_community_error(community["id"], str(exc))

            if not summary.errors:
                status = "ok"
            elif summary.communities_ok:
                status = "partial"
            else:
                status = "error"
            self.database.finish_scan(
                scan_id,
                status,
                summary.communities_ok,
                summary.posts_seen,
                summary.matches_found,
                "\n".join(summary.errors),
            )
            return summary
        except Exception as exc:
            self.database.finish_scan(
                scan_id,
                "error",
                summary.communities_ok,
                summary.posts_seen,
                summary.matches_found,
                str(exc),
            )
            raise

