from __future__ import annotations

import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import sys
import time

from .database import Database
from .matcher import match_text, searchable_post_text
from .notifier import Notifier, VKMessenger
from .reports import export_report_csv
from .scanner import Scanner
from .scheduler import DailyScheduler, ScanController
from .seed import seed_communities, seed_defaults
from .settings import Settings
from .vk_client import VKClient
from .web import serve


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vk-monitor",
        description="Ежедневный мониторинг публикаций в сообществах ВКонтакте",
    )
    parser.add_argument("--env-file", default=None, help="Путь к файлу .env")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init", help="Создать базу и загрузить запросы 2026 года")
    sub.add_parser("scan", help="Выполнить проверку сейчас")
    notify = sub.add_parser("notify", help="Отправить новые результаты в сообщения VK")
    notify.add_argument(
        "--require-config",
        action="store_true",
        help="Завершиться с ошибкой, если отправка не настроена",
    )
    sub.add_parser("serve", help="Запустить только веб-панель")
    sub.add_parser("run", help="Запустить веб-панель и ежедневный планировщик")
    sub.add_parser("demo", help="Добавить синтетические публикации для проверки интерфейса")
    sub.add_parser("doctor", help="Проверить настройки и подключение")

    export = sub.add_parser("export", help="Выгрузить найденные публикации в CSV")
    export.add_argument("output", nargs="?", default="exports/vk_report.csv")

    community = sub.add_parser("add-community", help="Добавить сообщество")
    community.add_argument("source")
    community.add_argument("--name", default="")
    community.add_argument(
        "--kind", choices=["own", "primary", "city", "media", "other"], default="other"
    )

    query = sub.add_parser("add-query", help="Добавить поисковое правило")
    query.add_argument("kind", choices=["hashtag", "phrase", "mention", "words_any", "words_all"])
    query.add_argument("pattern")
    query.add_argument("--label", default="")
    query.add_argument("--project", default="")
    query.add_argument("--category", default="")
    return parser


def _configured(settings: Settings) -> tuple[Database, int, int]:
    database = Database(settings.db_path)
    database.init()
    inserted, total = seed_defaults(database)
    seed_communities(database, os.getenv("VK_COMMUNITIES", ""))
    return database, inserted, total


def _scanner_factory(database, settings):
    return lambda: Scanner(database, settings)


def _notify(database: Database, settings: Settings, require_config: bool = False):
    result = Notifier(database, settings).run(require_config=require_config)
    if result.skipped:
        print("Уведомления VK не настроены — отправка пропущена")
        return result
    print(
        "Уведомления: "
        f"получателей {result.peers_ok}/{result.peers_total}, "
        f"сообщений {result.messages_sent}, публикаций {result.posts_sent}"
    )
    if result.errors:
        raise RuntimeError("; ".join(result.errors))
    return result


def add_demo(database: Database) -> int:
    database.add_community("demo_pervye", "Демонстрационное сообщество", "own")
    communities = database.list_communities()
    community = next(row for row in communities if row["source"] == "demo_pervye")
    database.update_community_resolution(
        community["id"], {"id": 900000001, "screen_name": "demo_pervye", "name": community["name"]}
    )
    now = int(time.time())
    demo_posts = [
        {
            "id": 1,
            "owner_id": -900000001,
            "date": now - 3600,
            "text": "Учебная публикация: команда готовится к муниципальному этапу Зарницы 2.0. #ПервыеКемь",
            "repost_text": "",
            "is_repost": False,
            "source_url": "https://vk.ru/wall-900000001_1",
            "likes": 12,
            "comments": 2,
            "reposts": 1,
            "views": 180,
            "raw": {"demo": True},
        },
        {
            "id": 2,
            "owner_id": -900000001,
            "date": now - 7200,
            "text": "Учебная публикация о мастер-классе по первой помощи. #ДвижениеПервых10",
            "repost_text": "",
            "is_repost": False,
            "source_url": "https://vk.ru/wall-900000001_2",
            "likes": 8,
            "comments": 0,
            "reposts": 0,
            "views": 95,
            "raw": {"demo": True},
        },
        {
            "id": 3,
            "owner_id": -900000001,
            "date": now - 10800,
            "text": "Учебный пример репоста.",
            "repost_text": "Активисты Движения Первых приняли участие в событии проекта Маршруты Первых.",
            "is_repost": True,
            "source_url": "https://vk.ru/wall-900000001_3",
            "likes": 5,
            "comments": 1,
            "reposts": 2,
            "views": 70,
            "raw": {"demo": True},
        },
    ]
    queries = database.list_queries(enabled_only=True)
    for post in demo_posts:
        post_db_id = database.upsert_post(community["id"], post)
        text = searchable_post_text(post)
        matches = []
        for query in queries:
            result = match_text(query["kind"], query["pattern"], text)
            if result.matched:
                matches.append(
                    {"query_id": query["id"], "evidence": result.evidence, "confidence": result.confidence}
                )
        database.replace_matches(post_db_id, matches)
    return len(demo_posts)


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        settings = Settings.from_env(args.env_file)
        database, inserted, total = _configured(settings)

        if args.command == "init":
            print(f"База готова: {settings.db_path}")
            print(f"Поисковые правила: {total}; добавлено сейчас: {inserted}")
            return 0

        if args.command == "add-community":
            created = database.add_community(args.source, args.name, args.kind)
            print("Сообщество добавлено" if created else "Такое сообщество уже есть")
            return 0

        if args.command == "add-query":
            created = database.add_query(args.kind, args.pattern, args.label, args.project, args.category)
            print("Запрос добавлен" if created else "Такой запрос уже есть")
            return 0

        if args.command == "demo":
            count = add_demo(database)
            print(f"Добавлено демонстрационных публикаций: {count}")
            return 0

        if args.command == "export":
            output = Path(args.output)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(export_report_csv(database, settings.timezone))
            print(f"Отчёт сохранён: {output.resolve()}")
            return 0

        if args.command == "doctor":
            print(f"Python: {sys.version.split()[0]}")
            print(f"База: {settings.db_path} — доступна")
            print(f"Сообществ: {len(database.list_communities())}")
            print(f"Токен VK: {'настроен' if settings.token_configured else 'не настроен'}")
            if settings.token_configured:
                VKClient(settings.access_token, settings.api_version, settings.link_domain).test_connection()
                print("Соединение с VK API: успешно")
            if settings.notification_partially_configured:
                raise ValueError(
                    "Для уведомлений задайте одновременно VK_NOTIFY_TOKEN и VK_NOTIFY_PEER_IDS"
                )
            print(
                "Уведомления VK: "
                f"{'настроены' if settings.notification_configured else 'не настроены'}"
            )
            if settings.notification_configured:
                VKMessenger(settings.notify_token, settings.api_version).test_connection()
                print(
                    "Доступ к сообщениям сообщества: успешно; "
                    f"получателей: {len(settings.notify_peer_ids)}"
                )
            return 0

        if args.command == "notify":
            _notify(database, settings, args.require_config)
            return 0

        if args.command == "run" and settings.notification_partially_configured:
            raise ValueError(
                "Для уведомлений задайте одновременно VK_NOTIFY_TOKEN и VK_NOTIFY_PEER_IDS"
            )

        after_scan = None
        if args.command == "run" and settings.notification_configured:
            after_scan = lambda _result: _notify(database, settings, require_config=True)
        controller = ScanController(_scanner_factory(database, settings), after_scan=after_scan)
        if args.command == "scan":
            if not settings.token_configured:
                raise ValueError("Добавьте VK_ACCESS_TOKEN в файл .env")
            result = controller.run_sync()
            print(
                "Проверка завершена: "
                f"сообществ {result['communities_ok']}/{result['communities_total']}, "
                f"постов {result['posts_seen']}, совпадений {result['matches_found']}"
            )
            if result["errors"]:
                for error in result["errors"]:
                    print(f"Ошибка: {error}", file=sys.stderr)
                return 1
            return 0

        if args.command == "serve":
            serve(database, settings, controller)
            return 0

        if args.command == "run":
            scheduler = DailyScheduler(controller, settings.scan_time, settings.timezone)
            scheduler.start()
            if settings.scan_on_start and settings.token_configured:
                controller.start()
            try:
                serve(database, settings, controller, scheduler)
            finally:
                scheduler.stop()
            return 0

        return 2
    except Exception as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
