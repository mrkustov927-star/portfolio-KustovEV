from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import re
import secrets
from zoneinfo import ZoneInfo

from .vk_client import VKClient


MAX_VK_MESSAGE_CHARS = 8_000


@dataclass(frozen=True, slots=True)
class DeliveryChunk:
    text: str
    post_ids: tuple[int, ...]


@dataclass(slots=True)
class NotifySummary:
    peers_total: int = 0
    peers_ok: int = 0
    messages_sent: int = 0
    posts_sent: int = 0
    empty_reports: int = 0
    skipped: bool = False
    errors: list[str] | None = None

    def to_dict(self) -> dict:
        return asdict(self)


class VKMessenger:
    """Small messages.send client that keeps the community token out of logs."""

    def __init__(self, access_token: str, api_version: str = "5.199"):
        self.client = VKClient(access_token, api_version, "vk.ru")

    def send_message(self, peer_id: int, message: str):
        return self.client.call(
            "messages.send",
            peer_id=int(peer_id),
            random_id=secrets.randbelow(2_147_483_647) + 1,
            message=message,
        )

    def test_connection(self):
        # Read-only validation of access to the community's conversations.
        return self.client.call("messages.getConversations", count=1)


def _compact(value: object, limit: int) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(text) <= limit:
        return text
    return text[: max(1, limit - 1)].rstrip() + "…"


def _row_value(row, name: str, default=""):
    try:
        value = row[name]
    except (KeyError, IndexError, TypeError):
        value = default
    return default if value is None else value


def _scan_header(scan, report_date: str, pending_total: int, selected: int) -> str:
    try:
        display_date = datetime.fromisoformat(report_date).strftime("%d.%m.%Y")
    except ValueError:
        display_date = report_date
    lines = [f"Мониторинг ВКонтакте · {display_date}"]
    if pending_total:
        if pending_total > selected:
            lines.append(f"Новых совпадений: {pending_total} · в этом отчёте: {selected}")
        else:
            lines.append(f"Новых совпадений: {pending_total}")
    else:
        lines.append("Новых совпадений нет")

    if scan:
        statuses = {"ok": "успешно", "partial": "частично", "error": "ошибка", "running": "выполняется"}
        status = statuses.get(str(_row_value(scan, "status")), str(_row_value(scan, "status")))
        lines.append(
            "Проверено сообществ: "
            f"{int(_row_value(scan, 'communities_ok', 0))}/"
            f"{int(_row_value(scan, 'communities_total', 0))} · "
            f"постов: {int(_row_value(scan, 'posts_seen', 0))} · статус: {status}"
        )
        error = _compact(_row_value(scan, "error"), 240)
        if error:
            lines.append(f"Ошибка проверки: {error}")
    return "\n".join(lines)


def _post_block(row, number: int, timezone_name: str) -> str:
    zone = ZoneInfo(timezone_name)
    published = datetime.fromtimestamp(
        int(_row_value(row, "published_ts", 0)), tz=timezone.utc
    ).astimezone(zone)
    community = _compact(
        _row_value(row, "community_name") or _row_value(row, "community_source"), 120
    )
    labels = _compact(_row_value(row, "matched_labels"), 240)
    projects = _compact(_row_value(row, "matched_projects"), 180)
    source_type = "репост" if int(_row_value(row, "is_repost", 0)) else "оригинал"
    excerpt_source = " ".join(
        value
        for value in (
            str(_row_value(row, "text", "")).strip(),
            str(_row_value(row, "repost_text", "")).strip(),
        )
        if value
    )
    excerpt = _compact(excerpt_source, 260)
    lines = [f"{number}. {community}", f"Найдено: {labels}"]
    if projects:
        lines.append(f"Проект: {projects}")
    lines.append(
        f"{published:%d.%m.%Y %H:%M} · {source_type} · "
        f"просмотры: {int(_row_value(row, 'views', 0))}"
    )
    if excerpt:
        lines.append(excerpt)
    lines.append(str(_row_value(row, "source_url")))
    return "\n".join(lines)


def build_delivery_chunks(
    rows,
    pending_total: int,
    scan,
    timezone_name: str,
    report_date: str,
    max_chars: int = MAX_VK_MESSAGE_CHARS,
) -> list[DeliveryChunk]:
    """Build messages below VK's 9000-character schema limit."""
    selected = len(rows)
    header = _scan_header(scan, report_date, pending_total, selected)
    chunks: list[DeliveryChunk] = []
    blocks: list[str] = []
    post_ids: list[int] = []

    def flush() -> None:
        if not blocks:
            return
        chunks.append(DeliveryChunk(header + "\n\n" + "\n\n".join(blocks), tuple(post_ids)))
        blocks.clear()
        post_ids.clear()

    for number, row in enumerate(rows, start=1):
        block = _post_block(row, number, timezone_name)
        candidate = header + "\n\n" + "\n\n".join([*blocks, block])
        if blocks and len(candidate) > max_chars:
            flush()
            candidate = header + "\n\n" + block
        if len(candidate) > max_chars:
            available = max(80, max_chars - len(header) - 2)
            block = _compact(block, available)
        blocks.append(block)
        post_ids.append(int(_row_value(row, "id")))
    flush()
    return chunks


class Notifier:
    def __init__(self, database, settings, messenger=None):
        self.database = database
        self.settings = settings
        self.messenger = messenger or (
            VKMessenger(settings.notify_token, settings.api_version)
            if settings.notification_configured
            else None
        )

    def run(self, require_config: bool = False) -> NotifySummary:
        summary = NotifySummary(
            peers_total=len(self.settings.notify_peer_ids),
            errors=[],
        )
        if self.settings.notification_partially_configured:
            raise ValueError(
                "Для уведомлений задайте одновременно VK_NOTIFY_TOKEN и VK_NOTIFY_PEER_IDS"
            )
        if not self.settings.notification_configured:
            if require_config:
                raise ValueError(
                    "Уведомления не настроены: добавьте VK_NOTIFY_TOKEN и VK_NOTIFY_PEER_IDS"
                )
            summary.skipped = True
            return summary

        zone = ZoneInfo(self.settings.timezone)
        report_date = datetime.now(zone).date().isoformat()
        scans = self.database.list_scans(1)
        scan = scans[0] if scans else None

        for peer_number, peer_id in enumerate(self.settings.notify_peer_ids, start=1):
            try:
                pending_total = self.database.count_unnotified_matched_posts(peer_id)
                rows = self.database.list_unnotified_matched_posts(
                    peer_id, self.settings.notify_max_posts
                )
                if rows:
                    chunks = build_delivery_chunks(
                        rows,
                        pending_total,
                        scan,
                        self.settings.timezone,
                        report_date,
                    )
                    for chunk in chunks:
                        self.messenger.send_message(peer_id, chunk.text)
                        self.database.record_notification_delivery(
                            peer_id, report_date, chunk.post_ids
                        )
                        summary.messages_sent += 1
                        summary.posts_sent += len(chunk.post_ids)
                elif (
                    self.settings.notify_empty
                    and not self.database.has_notification_run(peer_id, report_date)
                ):
                    message = _scan_header(scan, report_date, 0, 0)
                    self.messenger.send_message(peer_id, message)
                    self.database.record_notification_delivery(peer_id, report_date, ())
                    summary.messages_sent += 1
                    summary.empty_reports += 1
                summary.peers_ok += 1
            except Exception as exc:  # one bad recipient must not block the others
                summary.errors.append(f"получатель {peer_number}: {exc}")
        return summary
