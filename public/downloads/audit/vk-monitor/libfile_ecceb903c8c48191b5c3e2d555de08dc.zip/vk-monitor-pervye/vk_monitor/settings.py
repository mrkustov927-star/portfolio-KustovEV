from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import re


def load_env_file(path: Path) -> None:
    """Load a small .env file without third-party dependencies."""
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        if key:
            os.environ.setdefault(key, value)


def _as_int(name: str, default: int, minimum: int = 0) -> int:
    raw = os.getenv(name, str(default))
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} должен быть целым числом") from exc
    if value < minimum:
        raise ValueError(f"{name} должен быть не меньше {minimum}")
    return value


def _as_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name, "1" if default else "0").strip().lower()
    return raw in {"1", "true", "yes", "да", "on"}


def parse_notify_peer_ids(raw: str) -> tuple[int, ...]:
    """Parse user IDs, direct peer IDs and ``chat:<id>`` aliases."""
    peers: list[int] = []
    for item in re.split(r"[,;\s]+", raw.strip()):
        if not item:
            continue
        prefix, separator, value = item.partition(":")
        try:
            if separator and prefix.lower() == "chat":
                chat_id = int(value)
                if not 1 <= chat_id <= 100_000_000:
                    raise ValueError
                peer_id = 2_000_000_000 + chat_id
            elif separator and prefix.lower() in {"user", "peer"}:
                peer_id = int(value)
            elif separator:
                raise ValueError
            else:
                peer_id = int(item)
        except ValueError as exc:
            raise ValueError(
                "VK_NOTIFY_PEER_IDS должен содержать ID через запятую, "
                "например user:123456 или chat:7"
            ) from exc
        if peer_id == 0:
            raise ValueError("VK_NOTIFY_PEER_IDS не может содержать нулевой ID")
        if peer_id not in peers:
            peers.append(peer_id)
    return tuple(peers)


@dataclass(frozen=True, slots=True)
class Settings:
    root: Path
    db_path: Path
    access_token: str
    api_version: str
    host: str
    port: int
    scan_time: str
    timezone: str
    scan_on_start: bool
    initial_days: int
    lookback_days: int
    max_pages_per_community: int
    link_domain: str
    web_password: str
    notify_token: str
    notify_peer_ids: tuple[int, ...]
    notify_empty: bool
    notify_max_posts: int

    @property
    def token_configured(self) -> bool:
        return bool(self.access_token.strip())

    @property
    def notification_configured(self) -> bool:
        return bool(self.notify_token.strip() and self.notify_peer_ids)

    @property
    def notification_partially_configured(self) -> bool:
        return bool(self.notify_token.strip()) != bool(self.notify_peer_ids)

    @property
    def is_loopback(self) -> bool:
        return self.host in {"127.0.0.1", "localhost", "::1"}

    @classmethod
    def from_env(cls, env_file: str | Path | None = None) -> "Settings":
        root = Path(__file__).resolve().parent.parent
        requested = Path(env_file) if env_file else Path(os.getenv("VK_MONITOR_ENV_FILE", ".env"))
        if not requested.is_absolute():
            requested = Path.cwd() / requested
        load_env_file(requested)

        db_path = Path(os.getenv("VK_MONITOR_DB", "data/vk_monitor.db"))
        if not db_path.is_absolute():
            db_path = Path.cwd() / db_path

        scan_time = os.getenv("VK_SCAN_TIME", "08:00").strip()
        parts = scan_time.split(":")
        if len(parts) != 2:
            raise ValueError("VK_SCAN_TIME должен быть в формате ЧЧ:ММ")
        try:
            hour, minute = (int(part) for part in parts)
        except ValueError as exc:
            raise ValueError("VK_SCAN_TIME должен быть в формате ЧЧ:ММ") from exc
        if not 0 <= hour <= 23 or not 0 <= minute <= 59:
            raise ValueError("VK_SCAN_TIME содержит недопустимое время")

        link_domain = os.getenv("VK_LINK_DOMAIN", "vk.ru").strip().lower()
        if link_domain not in {"vk.ru", "vk.com"}:
            raise ValueError("VK_LINK_DOMAIN должен быть vk.ru или vk.com")

        settings = cls(
            root=root,
            db_path=db_path,
            access_token=os.getenv("VK_ACCESS_TOKEN", "").strip(),
            api_version=os.getenv("VK_API_VERSION", "5.199").strip(),
            host=os.getenv("VK_MONITOR_HOST", "127.0.0.1").strip(),
            port=_as_int("VK_MONITOR_PORT", 8787, 1),
            scan_time=f"{hour:02d}:{minute:02d}",
            timezone=os.getenv("VK_TIMEZONE", "Europe/Moscow").strip(),
            scan_on_start=_as_bool("VK_SCAN_ON_START", False),
            initial_days=_as_int("VK_INITIAL_DAYS", 30, 1),
            lookback_days=_as_int("VK_LOOKBACK_DAYS", 7, 1),
            max_pages_per_community=_as_int("VK_MAX_PAGES_PER_COMMUNITY", 30, 1),
            link_domain=link_domain,
            web_password=os.getenv("VK_MONITOR_PASSWORD", ""),
            notify_token=os.getenv("VK_NOTIFY_TOKEN", "").strip(),
            notify_peer_ids=parse_notify_peer_ids(os.getenv("VK_NOTIFY_PEER_IDS", "")),
            notify_empty=_as_bool("VK_NOTIFY_EMPTY", True),
            notify_max_posts=_as_int("VK_NOTIFY_MAX_POSTS", 50, 1),
        )
        if not settings.is_loopback and not settings.web_password:
            raise ValueError(
                "Для запуска не на локальном адресе задайте VK_MONITOR_PASSWORD"
            )
        return settings
